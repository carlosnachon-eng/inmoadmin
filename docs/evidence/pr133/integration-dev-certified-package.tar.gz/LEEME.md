# PR133 — integración local con Supabase DEV real

Destino único: `inmoadmin-dev / hjfwjnejbcpmknvfpdcq`.
Candidato funcional: `41b74c9abf919968791f6944d75c295261f0f2a0`.

No ejecuta la migración, los checks ni los ocho archivos de la certificación SQL cerrada.
Reutiliza exclusivamente los validadores de conexión/TLS de su lanzador, la CA oficial
ya recibida, la aplicación existente y las funciones de integración existentes.

`capture.jxa` contiene una sola ventana nativa con tres campos ocultos: dos claves API
DEV y contraseña PostgreSQL. No solicita cadena ni exige un marcador. Reutiliza los
campos oficiales ya verificados: host `aws-0-us-east-2.pooler.supabase.com`, puerto 5432,
usuario `postgres.hjfwjnejbcpmknvfpdcq`, base `postgres`, proyecto DEV autorizado.
La contraseña pasa intacta al campo `password`, sin trim ni codificación URL. El resultado
viaja por pipe privado a memoria del proceso; no se guarda ni se imprime.

`local-server.cjs` arranca Next 14.1.0 sólo en `127.0.0.1`, con Supabase JS 2.116.0.
La clave administrativa se entrega por stdin y sólo existe en el proceso servidor.
El único mock de red servidor es GET de un contacto Respond sintético específico.
Las solicitudes Auth/REST/RPC de Supabase DEV son reales y sus respuestas no se sustituyen.
No contiene endpoints nuevos ni cambios del código del producto.

`run-integration.mjs` prepara dos usuarios sintéticos mediante Auth Admin API, sin enviar
comunicaciones. Usa login de contraseña real desde la UI, perfil admin/asesor real, endpoint
administrativo real y RPC instalada. Reutiliza `invokeShadowPhase3A` con un callback de
modelo sintético y consultas reales a DEV. Conserva evidencia del resolver en un único
run explícitamente sintético para comprobar el endpoint y la UI de observabilidad reales.
No presenta ese run sintético como tráfico natural ni como evaluación de calidad de IA.

El namespace reservado es `pr133-ui-dev-20260921`; UUID base
`133c2026-0921-4000-8000-...`. Primero comprueba ausencia de colisiones, esquema y triggers.
La limpieza elimina sólo sus actores, sesiones, auditoría, links, candidato, identidad,
unidad, condominio y run/message/conversation propios. Inspecciona FKs antes de borrar
padres, sin CASCADE ni desactivar protecciones. Si falla, informa inventario residual.

El marcador `integration-fields-attempt.claim` impide reejecutar accidentalmente. Los
marcadores/reportes de los dos intentos anteriores se conservan. No borrar ni
rearmar para repetir un error sin diagnóstico. `--prepare-only` no solicita credenciales
ni accede a DEV: sólo comprueba rutas, versión, CA e imports.

Evidencia de este intento: `integration-fields-report.json`, sólo métricas y metadatos sanitizados. No se guardan
contraseñas, claves, tokens, cookies, storageState, trazas HAR ni cuerpos de Auth.
