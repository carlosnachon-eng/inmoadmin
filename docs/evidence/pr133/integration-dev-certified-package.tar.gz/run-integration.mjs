// A single bounded integration of the existing application and fixtures. NOT the closed SQL suite.
import {readFile,writeFile,stat,symlink,lstat,unlink,readdir,open} from 'node:fs/promises';
import {createHash,randomBytes} from 'node:crypto';
import {spawn,execFileSync} from 'node:child_process';
import {createRequire} from 'node:module';
import {setTimeout as delay} from 'node:timers/promises';
import {pathToFileURL,fileURLToPath} from 'node:url';
import net from 'node:net';
import {validateOfficialRoot,clientConfig,assertEffectiveTls,safeError} from '/private/tmp/pr133-dev-behavioral.vT0Zln/run-dev-certification.mjs';
import {chromium} from '/Users/carlos/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright/index.mjs';
import pg from '/private/tmp/condominium-identity-pg.2O15pu/node_modules/pg/lib/index.js';
const DIR='/private/tmp/pr133-ui-dev.koGNRE',REPO='/Users/carlos/Documents/ChatGPT/inmoadmin/condominium-owner-canonical-identity';
const DEP='/Users/carlos/Documents/ChatGPT/inmoadmin/fase-3c-canonical-identity-resolution/node_modules';
const require=createRequire(DEP+'/../package.json'),{createClient}=require('@supabase/supabase-js');
const PROJECT='hjfwjnejbcpmknvfpdcq',URLDEV=`https://${PROJECT}.supabase.co`,HEAD='41b74c9abf919968791f6944d75c295261f0f2a0';
// Exact public route already validated in the authorized official Session pooler.
// Do not derive/reconstruct the hostname from a project/region or accept a URI.
export const OFFICIAL_DEV_ROUTE=Object.freeze({project:PROJECT,host:'aws-0-us-east-2.pooler.supabase.com',port:5432,user:'postgres.hjfwjnejbcpmknvfpdcq',database:'postgres',mode:'session_pooler'});
const TAG='pr133-ui-dev-20260921',contactId=TAG+'-owner',phone='520000133301';
const uuid=n=>'133c2026-0921-4000-8000-'+String(n).padStart(12,'0');
const condoId=uuid(20),unitId=uuid(101),conversationId=uuid(201),messageId=uuid(202),runId=uuid(203);
const emails=[`${TAG}.admin@example.invalid`,`${TAG}.asesor@example.invalid`];
const digest=s=>createHash('sha256').update(s).digest('hex');
const report={candidate:HEAD,project:PROJECT,sql_certification:'CLOSED_NOT_REPEATED',started_at:new Date().toISOString(),steps:[],simulated:['Respond GET synthetic contact','3A model deterministic callback'],real:['application UI','Supabase Auth','server authorization','Supabase DEV REST/RPC','before-3A resolver','observability'],cleanup:{result:'NOT_STARTED',remaining:[]},external_traces:[]};
const emit=x=>process.stdout.write(JSON.stringify(x)+'\n');
const fail=code=>Object.assign(Error(code),{safeCode:code});
const must=(value,code)=>{if(!value)throw fail(code);};
const pass=(stage,detail={})=>{const r={stage,result:'PASS',...detail};report.steps.push(r);emit(r);};
const diagnostic=(code,object,expected,observed,ok,source)=>({code,object,expected,observed:observed??null,result:ok?'PASS':'FAIL',source});
export function evaluatePostgresContext(row={},transport={}){
  const name=v=>typeof v==='string'&&/^[a-z_][a-z0-9_.-]{0,62}$/.test(v)?v:null;
  const bool=v=>typeof v==='boolean'?v:null;
  const original=[
    diagnostic('postgres_role_mismatch','current_user','postgres',name(row.db_role),row.db_role==='postgres','previously validated DEV launcher; official pooler user postgres.<project>'),
    diagnostic('postgres_database_mismatch','current_database()','postgres',name(row.db),row.db==='postgres','official DEV connection path /postgres'),
    {...diagnostic('backend_ssl_not_true','pg_stat_ssl.ssl',true,bool(row.backend_ssl),row.backend_ssl===true,'integration launcher assumption, not applicable to client-to-pooler TLS'),required_for_client_tls:false,applicable_to:'PostgreSQL backend connection only'}
  ];
  const tls={encrypted:bool(transport.encrypted),authorized:bool(transport.authorized),hostname_verified:bool(transport.hostname_verified)};
  const checks=[...original.slice(0,2),diagnostic('client_tls_verification_failed','verified client TLS socket',{encrypted:true,authorized:true,hostname_verified:true},tls,Object.values(tls).every(v=>v===true),'unchanged strict official CA config, default hostname verification, actual pg TLS socket')];
  const tlsFailures=Object.entries(tls).filter(([,v])=>v!==true).map(([k])=>'client_tls_'+k+'_failed');
  return {previous_attempt:'no disponible del intento anterior',original_conditions:original,checks,failed_codes:[...checks.slice(0,2).filter(c=>c.result==='FAIL').map(c=>c.code),...tlsFailures],passed:checks.every(c=>c.result==='PASS')};
}
export function checkMetadata(reportRows,code,object,expected,observed,ok,source='local integration precondition'){
  const row=diagnostic(code,object,expected,observed,ok,source);reportRows.push(row);return row;
}
export function evaluateTarget(route=OFFICIAL_DEV_ROUTE){
  const publicText=v=>typeof v==='number'?v:typeof v==='string'&&/^[a-zA-Z0-9_.-]{1,160}$/.test(v)?v:null;
  return [
    diagnostic('pooler_project_mismatch','project',PROJECT,publicText(route.project),route.project===PROJECT,'exclusive authorized DEV project'),
    diagnostic('pooler_host_mismatch','host',OFFICIAL_DEV_ROUTE.host,publicText(route.host),route.host===OFFICIAL_DEV_ROUTE.host,'previously validated official DEV Session pooler'),
    diagnostic('pooler_port_mismatch','port',5432,publicText(route.port),route.port===5432,'authorized Session pooler port'),
    diagnostic('pooler_project_user_mismatch','pooler user',OFFICIAL_DEV_ROUTE.user,publicText(route.user),route.user===OFFICIAL_DEV_ROUTE.user,'exclusive authorized project routing'),
    diagnostic('pooler_database_mismatch','database','postgres',publicText(route.database),route.database==='postgres','previously validated official database'),
    diagnostic('pooler_mode_mismatch','connection mode','session_pooler',publicText(route.mode),route.mode==='session_pooler','authorized official connection method')];
}
export function composeDevCredential(password,route=OFFICIAL_DEV_ROUTE){
  const failed=evaluateTarget(route).find(c=>c.result==='FAIL');if(failed)throw fail(failed.code);
  if(Object.keys(route).some(k=>!Object.hasOwn(OFFICIAL_DEV_ROUTE,k)))throw fail('unexpected_route_option');
  if(typeof password!=='string'||password.length===0)throw fail('postgres_password_missing');
  if(password.includes('\0'))throw fail('postgres_password_nul_rejected');
  // Exact password value, no trim, percent encoding/decoding, interpolation or URL.
  return {host:route.host,port:route.port,user:route.user,database:route.database,mode:route.mode,password};
}
export function createDevClientConfig(password,ca,route=OFFICIAL_DEV_ROUTE){
  const credential=composeDevCredential(password,route),config=clientConfig(credential,ca);
  config.application_name=TAG;
  const client=new pg.Client(config);assertEffectiveTls(client,config);
  if(client.connectionParameters.user!==credential.user||client.connectionParameters.database!==credential.database||client.connectionParameters.password!==password)throw fail('effective_client_fields_mismatch');
  return {credential,config,client};
}
export function queryMetadata(text){return {command:String(text).trim().split(/\s+/)[0].toUpperCase(),objects:[...String(text).matchAll(/\b(?:from|into|update|join)\s+((?:auth|public|pg_catalog)\.[a-z_]+|pg_[a-z_]+)/gi)].map(m=>m[1])};}
const precheck=(code,object,expected,observed,ok)=>{const row=checkMetadata(report.preconditions??=[],code,object,expected,observed,ok);if(!ok){emit({stage:'precondition_failed',...row});throw fail(code);}return row;};
function errorMetadata(error){
  const result=safeError(error);for(const k of ['schema','table','column','constraint','routine'])if(typeof error?.[k]==='string'&&/^[a-zA-Z_][a-zA-Z0-9_.]{0,100}$/.test(error[k]))result[k]=error[k];
  if(typeof error?.code==='string'&&/^[a-zA-Z0-9_]{2,80}$/.test(error.code))result.provider_code=error.code;
  if(Number.isInteger(error?.status))result.http=error.status;return result;
}
async function assertNoAdminKeyInBrowserArtifacts(){
  let files=0;async function walk(dir){for(const entry of await readdir(dir,{withFileTypes:true}).catch(()=>[])){
    const path=dir+'/'+entry.name;if(entry.isDirectory())await walk(path);else if(entry.isFile()){
      const buffer=await readFile(path);must(!buffer.includes(Buffer.from(keys.adminKey)),'administrative_key_in_browser_artifact');files++;
    }
  }}await walk(REPO+'/.next/static');pass('administrative_key_not_in_client_artifacts',{files_scanned:files});
}
let db,keys,credential,browser,server,createdDependencyLink=false,fixtureStart=false,actorIds=[],candidateIds=[],identityIds=[],sessionIds=[];
const quote=s=>{must(/^[a-z_][a-z0-9_]*$/.test(s),'unsafe_catalog_identifier');return '"'+s+'"';};
async function capture(){
  emit({stage:'secure_capture_opening',fields:['public DEV API key','administrative DEV API key','PostgreSQL password'],single_form:true,connection_uri_requested:false});
  return new Promise((resolve,reject)=>{
    const c=spawn('/usr/bin/osascript',['-l','JavaScript',DIR+'/capture.jxa'],{stdio:['ignore','pipe','pipe']});let out=[],err=[],size=0;
    const timer=setTimeout(()=>{c.kill('SIGTERM');reject(fail('secure_capture_timeout'));},600000);
    c.on('error',()=>{clearTimeout(timer);reject(fail('secure_capture_could_not_start'));});
    c.stdout.on('data',b=>{size+=b.length;if(size>16384){c.kill();reject(fail('capture_too_large'));}else out.push(b);});c.stderr.on('data',b=>err.push(b));
    c.on('close',code=>{clearTimeout(timer);const b=Buffer.concat(out),e=Buffer.concat(err);try{
    if(code!==0){report.capture_failure={exit_code:code,reason:'dialog_process_failure',credentials_received:false};throw fail('secure_capture_dialog_failed');}const value=JSON.parse(b.toString());
      if(value.status==='cancelled')throw fail('secure_capture_cancelled');must(value.status==='ok','secure_capture_unknown_outcome');resolve(value);
    }catch(e){reject(e.safeCode?e:fail('secure_capture_invalid_response'));}finally{b.fill(0);e.fill(0);out.forEach(x=>x.fill(0));err.forEach(x=>x.fill(0));}});
  });
}
async function preparation(){
  const manifest=(await readFile(DIR+'/package-integrity.sha256','utf8')).trim().split('\n');
  must(manifest.length===4,'integration_manifest_scope_changed');
  for(const line of manifest){const match=/^([a-f0-9]{64})  (capture\.jxa|local-server\.cjs|run-integration\.mjs|diagnostic\.test\.mjs)$/.exec(line);must(match,'invalid_integration_manifest');
    must(digest(await readFile(DIR+'/'+match[2]))===match[1],'integration_package_hash_mismatch');}
  must(execFileSync('git',['rev-parse','HEAD'],{cwd:REPO,encoding:'utf8'}).trim()===HEAD,'candidate_changed');
  must(require('@supabase/supabase-js/package.json').version==='2.116.0','sdk_version_changed');
  const ca=validateOfficialRoot(await readFile('/Users/carlos/Downloads/prod-ca-2021.crt'));
  must(ca.metadata.sha256==='80:70:25:AD:50:D4:ED:21:9D:2C:9C:7D:29:9C:00:4F:82:4E:B0:0C:F7:F6:5A:FE:F6:07:D0:7B:72:E6:CA:FA','official_ca_changed');
  for(const name of await readdir(REPO))must(!/^\.env(?:\.(local|development|production|test)(?:\.local)?)?$/.test(name),'unexpected_env_file');
  if(!await lstat(REPO+'/node_modules').catch(()=>null)){await symlink(DEP,REPO+'/node_modules');createdDependencyLink=true;}
  const {invokeShadowPhase3A}=await import(pathToFileURL(REPO+'/lib/shadow/ai/phase3AGateway.js'));
  must(typeof invokeShadowPhase3A==='function','gateway_not_loadable');
  must((await stat('/Applications/Google Chrome.app/Contents/MacOS/Google Chrome')).isFile(),'chrome_not_available');
  pass('preparation',{sdk:'2.116.0',next:require('next/package.json').version,modern_keys:true,ca_reused:true,fixtures:TAG,closed_sql_not_invoked:true});return ca;
}
const tables=['auth.users','auth.sessions','auth.refresh_tokens','auth.identities','auth.audit_log_entries','auth.mfa_amr_claims','auth.flow_state','auth.one_time_tokens','public.profiles','public.condominios','public.unidades_condominio','public.client_identities','public.client_identity_roles','public.client_source_links','public.client_reconciliation_candidates','public.client_reconciliation_candidate_sources','public.client_identity_audit','public.respond_identity_links','public.respond_identity_audit','public.shadow_conversations','public.shadow_messages','public.shadow_ai_runs'];
async function catalogAndCollisions(){
  // Preserve the established launcher check. With a Session pooler, pg_stat_ssl observes
  // the pooler-to-database backend, not the verified TLS socket from this Mac to Supavisor.
  // It must never replace or contradict the strict clientConfig/assertEffectiveTls checks.
  const q=await db.query('select current_user as db_role,current_database() as db,pg_backend_pid() as pid,(select ssl from pg_stat_ssl where pid=pg_backend_pid()) as backend_ssl');
  const observed=q.rows[0];
  report.database_context=evaluatePostgresContext(observed,{encrypted:db.connection.stream.encrypted,authorized:db.connection.stream.authorized,hostname_verified:db.connection.stream.authorized===true&&db.connectionParameters.ssl.servername===credential.host&&!Object.hasOwn(db.connectionParameters.ssl,'checkServerIdentity')});
  report.database_context.backend_pid=observed.pid;
  emit({stage:'postgres_context_diagnostic',...report.database_context});
  if(!report.database_context.passed)throw fail(report.database_context.failed_codes[0]);
  const triggers=(await db.query(`select n.nspname schema,c.relname table,t.tgname name,p.proname function,md5(p.prosrc) body_hash from pg_trigger t join pg_class c on c.oid=t.tgrelid join pg_namespace n on n.oid=c.relnamespace join pg_proc p on p.oid=t.tgfoid where not t.tgisinternal and t.tgenabled<>'D' and (n.nspname||'.'||c.relname)=any($1::text[])`,[tables])).rows;
  const pinned=new Set(['25fe16f206acafd66f67b0967a19d706','221b2328c392a5be762e3944b6e07828','6bd79a33aff7c8ab1dab288dcd38226a']);
  for(const t of triggers)precheck('unexpected_fixture_trigger',t.schema+'.'+t.table+'.'+t.name,'previously reviewed trigger body',t,pinned.has(t.body_hash));
  precheck('auth_profile_trigger_missing','auth.users.on_auth_user_created','present',triggers.some(t=>t.schema==='auth'&&t.table==='users'&&t.name==='on_auth_user_created'),triggers.some(t=>t.schema==='auth'&&t.table==='users'&&t.name==='on_auth_user_created'));
  const required={ 'public.condominios':['id','nombre','activo'], 'public.unidades_condominio':['id','condominio_id','numero','activo','propietario_telefono','propietario_nombre'],
    'public.shadow_conversations':['id','provider','external_conversation_id','contact_hash','channel','first_message_at','last_message_at'],
    'public.shadow_messages':['id','conversation_id','provider','external_message_id','direction','occurred_at','sanitized_text','content_hash','provider_metadata'],
    'public.shadow_ai_runs':['id','message_id','status','execution_state','model','prompt_version','schema_version','input_kind','tool_results_json','started_at','completed_at']};
  for(const [table,columns] of Object.entries(required)){
    const r=(await db.query(`select a.attname from pg_attribute a where a.attrelid=to_regclass($1) and a.attnum>0 and not a.attisdropped and a.attnotnull and not a.atthasdef and a.attidentity='' and a.attgenerated='' and not a.attname=any($2::text[])`,[table,columns])).rows;
    const present=(await db.query('select to_regclass($1) present',[table])).rows[0].present;
    precheck('missing_integration_table',table,'table exists',present,Boolean(present));
    precheck('fixture_required_columns_missing',table,'every required no-default column supplied',{missing:r.map(x=>x.attname)},!r.length);
  }
  for(const [table,columns] of [['auth.sessions',['id','user_id']],['auth.refresh_tokens',['user_id']],['auth.identities',['user_id']],['auth.audit_log_entries',['payload']],['auth.mfa_amr_claims',['session_id']],['auth.flow_state',['user_id']],['auth.one_time_tokens',['user_id']]]){
    if(!(await db.query('select to_regclass($1) t',[table])).rows[0].t)continue;
    const found=(await db.query('select attname from pg_attribute where attrelid=to_regclass($1) and attnum>0 and not attisdropped',[table])).rows.map(r=>r.attname);
    precheck('auth_cleanup_schema_mismatch',table,columns,{present:found,missing:columns.filter(c=>!found.includes(c))},columns.every(c=>found.includes(c)));
  }
  const roles=(await db.query("select id from public.roles where id in('admin','asesor') order by id")).rows.map(r=>r.id);
  precheck('required_application_roles_missing','public.roles',['admin','asesor'],roles,roles.includes('admin')&&roles.includes('asesor'));
  const collision=await db.query(`select
    (select count(*) from auth.users where email=any($1::text[]))+
    (select count(*) from public.profiles where email=any($1::text[]))+
    (select count(*) from public.condominios where id=$2)+
    (select count(*) from public.unidades_condominio where id=$3 or public.condominium_identity_phone_digest(propietario_telefono)=$4)+
    (select count(*) from public.client_identities where phone_digest=$4)+
    (select count(*) from public.respond_identity_links where respond_contact_id=$5)+
    (select count(*) from public.client_reconciliation_candidates where respond_contact_id=$5)+
    (select count(*) from public.shadow_conversations where id=$6 or external_conversation_id=$5)+
    (select count(*) from public.shadow_messages where id=$7)+
    (select count(*) from public.shadow_ai_runs where id=$8) n`,[emails,condoId,unitId,digest(phone),contactId,conversationId,messageId,runId]);
  precheck('synthetic_fixture_collision','own fixture namespace',0,Number(collision.rows[0].n),Number(collision.rows[0].n)===0);
  for(const t of tables){const exists=(await db.query('select to_regclass($1) t',[t])).rows[0].t;
    if(exists)for(const permission of ['SELECT','DELETE']){const allowed=(await db.query('select has_table_privilege(current_user,$1,$2) allowed',[t,permission])).rows[0].allowed;precheck('fixture_cleanup_'+permission.toLowerCase()+'_denied',t,{permission,allowed:true},{permission,allowed},allowed===true);}
    else precheck('cleanup_table_missing',t,'present',null,['auth.flow_state','auth.one_time_tokens'].includes(t));}
  pass('fixture_preconditions',{collision_count:0,reviewed_trigger_count:triggers.length,roles:['admin','asesor'],tls:true});
}
async function noChildren(table,ids){
  if(!ids.length)return;
  const fks=(await db.query(`select cn.conname,n.nspname schema,c.relname table,ca.attname child,pa.attname parent,cardinality(cn.conkey) count
    from pg_constraint cn join pg_class c on c.oid=cn.conrelid join pg_namespace n on n.oid=c.relnamespace
    join pg_attribute ca on ca.attrelid=cn.conrelid and ca.attnum=cn.conkey[1]
    join pg_attribute pa on pa.attrelid=cn.confrelid and pa.attnum=cn.confkey[1]
    where cn.contype='f' and cn.confrelid=to_regclass($1)`,[table])).rows;
  for(const f of fks){must(f.count===1&&f.parent==='id','cleanup_composite_dependency_'+f.conname);
    const n=(await db.query(`select count(*)::int n from ${quote(f.schema)}.${quote(f.table)} where ${quote(f.child)}::text=any($1::text[])`,[ids])).rows[0].n;
    must(n===0,'cleanup_unexpected_child_'+f.schema+'_'+f.table+'_'+f.child);}
}
async function cleanup(){
  if(!db||!fixtureStart){report.cleanup={result:'NOT_NEEDED',remaining:[]};return;}
  await db.query('rollback');await db.query('begin');
  try{
    // Recover only the exact synthetic actors, including a possible lost createUser response.
    const actors=(await db.query("select id,raw_app_meta_data from auth.users where email=any($1::text[])",[emails])).rows;
    for(const a of actors)must(a.raw_app_meta_data?.fixture_package===TAG,'cleanup_actor_ownership_mismatch');actorIds=actors.map(a=>a.id);
    const candidates=(await db.query('select id,client_identity_id from public.client_reconciliation_candidates where respond_contact_id=$1',[contactId])).rows;
    candidateIds=candidates.map(c=>c.id);identityIds=[...new Set(candidates.map(c=>c.client_identity_id).filter(Boolean))];
    const links=(await db.query('select id,client_identity_id from public.respond_identity_links where respond_contact_id=$1',[contactId])).rows;
    identityIds=[...new Set([...identityIds,...links.map(l=>l.client_identity_id).filter(Boolean)])];
    for(const identity of identityIds){
      const ok=(await db.query(`select phone_digest=$2 and auth_user_id is null valid from public.client_identities where id=$1`,[identity,digest(phone)])).rows[0]?.valid;
      must(ok,'cleanup_identity_ownership_mismatch');
      must(!(await db.query("select 1 from public.client_source_links where client_identity_id=$1 and (source_type<>'condominium_unit_owner' or source_id<>$2)",[identity,unitId])).rowCount,'cleanup_nonfixture_source');
      must(!(await db.query('select 1 from public.respond_identity_links where client_identity_id=$1 and respond_contact_id<>$2',[identity,contactId])).rowCount,'cleanup_nonfixture_contact');
    }
    await noChildren('public.shadow_ai_runs',[runId]);await db.query('delete from public.shadow_ai_runs where id=$1 and prompt_version=$2',[runId,TAG]);
    await noChildren('public.shadow_messages',[messageId]);await db.query('delete from public.shadow_messages where id=$1 and external_message_id=$2',[messageId,TAG]);
    await noChildren('public.shadow_conversations',[conversationId]);await db.query('delete from public.shadow_conversations where id=$1 and external_conversation_id=$2',[conversationId,contactId]);
    await db.query('delete from public.respond_identity_audit where respond_contact_id=$1 and actor_profile_id=any($2::uuid[])',[contactId,actorIds]);
    await noChildren('public.respond_identity_links',links.map(l=>l.id));
    await db.query("delete from public.respond_identity_links where respond_contact_id=$1 and link_source='condominium_owner_admin_review' and confirmed_by=any($2::uuid[])",[contactId,actorIds]);
    await db.query("delete from public.client_identity_audit where actor_profile_id=any($1::uuid[]) and (candidate_id=any($2::uuid[]) or context_ids->>'unitId'=$3)",[actorIds,candidateIds,unitId]);
    await db.query("delete from public.client_reconciliation_candidate_sources where candidate_id=any($1::uuid[]) and source_type='condominium_unit_owner' and source_id=$2",[candidateIds,unitId]);
    await noChildren('public.client_reconciliation_candidates',candidateIds);await db.query('delete from public.client_reconciliation_candidates where id=any($1::uuid[])',[candidateIds]);
    await db.query("delete from public.client_source_links where client_identity_id=any($1::uuid[]) and source_type='condominium_unit_owner' and source_id=$2",[identityIds,unitId]);
    await db.query('delete from public.client_identity_roles where client_identity_id=any($1::uuid[])',[identityIds]);
    await noChildren('public.client_identities',identityIds);await db.query('delete from public.client_identities where id=any($1::uuid[])',[identityIds]);
    await noChildren('public.unidades_condominio',[unitId]);await db.query('delete from public.unidades_condominio where id=$1 and condominio_id=$2 and numero=$3',[unitId,condoId,TAG]);
    await noChildren('public.condominios',[condoId]);await db.query('delete from public.condominios where id=$1 and nombre=$2',[condoId,TAG]);
    // Explicit Auth children only. Reject any other dependent row; never cascade/delete unrelated users.
    sessionIds=(await db.query('select id from auth.sessions where user_id=any($1::uuid[])',[actorIds])).rows.map(s=>s.id);
    await db.query('delete from auth.refresh_tokens where user_id=any($1::text[])',[actorIds]);
    await db.query('delete from auth.mfa_amr_claims where session_id=any($1::uuid[])',[sessionIds]);
    for(const t of ['auth.flow_state','auth.one_time_tokens'])if((await db.query('select to_regclass($1) t',[t])).rows[0].t)await db.query(`delete from ${t} where user_id=any($1::uuid[])`,[actorIds]);
    await noChildren('auth.sessions',sessionIds);await db.query('delete from auth.sessions where id=any($1::uuid[])',[sessionIds]);
    await db.query('delete from auth.identities where user_id=any($1::uuid[])',[actorIds]);
    await db.query("delete from auth.audit_log_entries where payload->>'actor_id'=any($1::text[]) or payload->>'user_id'=any($1::text[]) or payload->>'actor_username'=any($2::text[])",[actorIds,emails]);
    await noChildren('public.profiles',actorIds);await db.query('delete from public.profiles where id=any($1::uuid[]) and email=any($2::text[])',[actorIds,emails]);
    await noChildren('auth.users',actorIds);await db.query("delete from auth.users where id=any($1::uuid[]) and raw_app_meta_data->>'fixture_package'=$2",[actorIds,TAG]);
    await db.query('commit');report.cleanup={result:'PASS',remaining:[],actors_removed:actorIds.length,sessions_removed:sessionIds.length,inventory:await inventory()};
    must(report.cleanup.inventory.every(x=>x.count===0),'cleanup_residue_detected');pass('cleanup',{remaining:[],actors_removed:actorIds.length,sessions_removed:sessionIds.length});
  }catch(error){await db.query('rollback');report.cleanup={result:'FAIL',error:safeError(error),remaining:await inventory()};throw error;}
}
async function inventory(){
  const checks=[['auth.users','email=any($1::text[])',[emails]],['auth.sessions','user_id=any($1::uuid[])',[actorIds]],['auth.refresh_tokens','user_id=any($1::text[])',[actorIds]],['auth.identities','user_id=any($1::uuid[])',[actorIds]],['public.profiles','email=any($1::text[])',[emails]],['public.condominios','id=$1',[condoId]],['public.unidades_condominio','id=$1',[unitId]],['public.client_reconciliation_candidates','respond_contact_id=$1',[contactId]],['public.client_reconciliation_candidate_sources','source_id=$1',[unitId]],['public.client_source_links','source_id=$1',[unitId]],['public.client_identities','id=any($1::uuid[])',[identityIds]],['public.client_identity_roles','client_identity_id=any($1::uuid[])',[identityIds]],['public.respond_identity_links','respond_contact_id=$1',[contactId]],['public.client_identity_audit','actor_profile_id=any($1::uuid[])',[actorIds]],['public.respond_identity_audit','respond_contact_id=$1',[contactId]],['public.shadow_conversations','id=$1',[conversationId]],['public.shadow_messages','id=$1',[messageId]],['public.shadow_ai_runs','id=$1',[runId]]];
  checks.push(['auth.audit_log_entries',"payload->>'actor_id'=any($1::text[]) or payload->>'user_id'=any($1::text[]) or payload->>'actor_username'=any($2::text[])",[actorIds,emails]],['auth.mfa_amr_claims','session_id=any($1::uuid[])',[sessionIds]]);
  for(const t of ['auth.flow_state','auth.one_time_tokens'])if((await db.query('select to_regclass($1) t',[t])).rows[0].t)checks.push([t,'user_id=any($1::uuid[])',[actorIds]]);
  const result=[];for(const [table,where,values] of checks){const r=await db.query(`select count(*)::int n from ${table} where ${where}`,values);result.push({table,count:r.rows[0].n});}return result;
}
async function startServer(){
  const socket=net.createServer();await new Promise(ok=>socket.listen(0,'127.0.0.1',ok));const port=socket.address().port;await new Promise(ok=>socket.close(ok));
  server=spawn(process.execPath,[DIR+'/local-server.cjs'],{cwd:REPO,env:{PATH:process.env.PATH,HOME:process.env.HOME,TMPDIR:process.env.TMPDIR,NODE_NO_WARNINGS:'1'},stdio:['pipe','pipe','pipe']});
  let rest='',ready=false;server.stdout.on('data',b=>{rest+=b.toString();let i;while((i=rest.indexOf('\n'))>=0){const line=rest.slice(0,i);rest=rest.slice(i+1);try{const row=JSON.parse(line);if(row.stage==='local_ready')ready=true;if(['local_ready','respond_mock','real_dev_response','server_start_failed'].includes(row.stage))report.external_traces.push(row);}catch{}}});server.stderr.on('data',()=>{});
  server.stdin.end(JSON.stringify({project:PROJECT,publicKey:keys.publicKey,adminKey:keys.adminKey,repo:REPO,port,contactId,phone}));
    const until=Date.now()+120000;while(!ready&&Date.now()<until&&server.exitCode===null)await delay(200);precheck('local_server_not_ready','Next local startup',{ready:true},{ready,exit_code:server.exitCode,timeout:Date.now()>=until},ready);
  report.local_origin=`http://127.0.0.1:${port}`;pass('local_application_ready',{loopback_only:true,port});return report.local_origin;
}
async function runUi(admin,origin,actors){
  browser=await chromium.launch({channel:'chrome',headless:true,args:['--disable-background-networking','--disable-component-update','--disable-default-apps']});
  const contexts=[];const apiResponses=[];
  async function contextFor(actor){
    const context=await browser.newContext({serviceWorkers:'block'});contexts.push(context);
    await context.route('**/*',async route=>{
      const r=route.request(),u=new URL(r.url());
      if(u.origin!==origin&&u.origin!==URLDEV)return route.abort();
      if(u.origin===origin&&r.method()==='POST'){
        if(u.pathname!=='/api/operaciones/client-reconciliation')return route.abort();
        const body=JSON.parse(r.postData()||'{}');if(!['condominium_list','condominium_prepare','condominium_confirm'].includes(body.action))return route.abort();
        if(body.action==='condominium_prepare'&&(body.unitId!==unitId||body.respondContactId!==contactId))return route.abort();
        if(body.action==='condominium_confirm'&&!candidateIds.includes(body.candidateId))return route.abort();
      }
      if(u.origin===URLDEV&&!['GET','HEAD'].includes(r.method())&&!['/auth/v1/token','/auth/v1/logout'].includes(u.pathname))return route.abort();
      return route.continue();
    });
    const page=await context.newPage();page.setDefaultTimeout(45000);
    page.on('response',async r=>{if(r.url()===origin+'/api/operaciones/client-reconciliation'&&r.request().method()==='POST'){
      try{const b=JSON.parse(r.request().postData()||'{}'),j=await r.json();apiResponses.push({action:b.action,http:r.status(),ok:j.ok,status:j.result?.status,reason:j.result?.reason,error:j.error});}catch{}
    }});
    await page.goto(origin,{waitUntil:'domcontentloaded'});
    await page.locator('input[type=email]').fill(actor.email);await page.locator('input[type=password]').fill(actor.password);
    const login=page.waitForResponse(r=>r.url().startsWith(URLDEV+'/auth/v1/token')&&r.request().method()==='POST');
    await page.getByRole('button',{name:'Entrar',exact:true}).click();const lr=await login;report.last_auth_http={role:actor.role,http:lr.status()};must(lr.status()===200,'real_auth_login_failed_'+actor.role);
    const session=await lr.json();must(session.user.id===actor.id&&session.access_token,'real_auth_session_mismatch');
    await page.waitForFunction(()=>!document.querySelector('input[type=password]'));pass('real_ui_auth_'+actor.role,{http:lr.status(),session:true});
    return {context,page,session};
  }
  const active=await contextFor(actors[0]);
  await active.page.goto(origin+'/coordinador-ia-sombra',{waitUntil:'domcontentloaded'});
  const summary=active.page.locator('summary').filter({hasText:'Identidad canónica — propietarios de Condominios'});await summary.waitFor();await summary.click();
  async function clickRequest(button,expectedAction){
    const wait=active.page.waitForResponse(r=>r.url()===origin+'/api/operaciones/client-reconciliation'&&r.request().method()==='POST'&&JSON.parse(r.request().postData()||'{}').action===expectedAction);
    await button.click();const r=await wait;const body=await r.json();report.last_ui_operation={action:expectedAction,http:r.status(),ok:body.ok,status:body.result?.status||null,reason:body.result?.reason||null,error:typeof body.error==='string'&&/^[a-z_]{1,100}$/.test(body.error)?body.error:null};must(r.status()===200&&body.ok,'ui_endpoint_'+expectedAction+'_failed');return body;
  }
  const panel=active.page.locator('details').filter({has:summary});
  const listing=await clickRequest(panel.getByRole('button',{name:'Consultar unidades y candidatos'}),'condominium_list');
  precheck('local_prepare_gate_off','prepare capability',true,listing.capabilities.prepare,listing.capabilities.prepare===true);
  precheck('local_review_gate_off','review capability',true,listing.capabilities.review,listing.capabilities.review===true);
  precheck('own_unit_not_available','synthetic unit in list',true,listing.units.some(u=>u.unitId===unitId),listing.units.some(u=>u.unitId===unitId));
  await panel.locator('select').selectOption(unitId);await panel.getByLabel('ID estructurado del contacto Respond').fill(contactId);
  const prepared=await clickRequest(panel.getByRole('button',{name:'Preparar candidato',exact:true}),'condominium_prepare');
  must(prepared.result.status==='requires_review','candidate_not_requires_review');
  candidateIds=(await db.query('select id from public.client_reconciliation_candidates where respond_contact_id=$1',[contactId])).rows.map(c=>c.id);must(candidateIds.length===1,'candidate_count_not_one');
  const {loadCondominiumIdentityBefore3A}=await import(pathToFileURL(REPO+'/lib/shadow/condominiumIdentity.js'));
  must(await loadCondominiumIdentityBefore3A(admin,contactId)===null,'unapproved_candidate_resolved');pass('ui_prepare_candidate',{http:200,status:'requires_review',before_approval:'unresolved'});
  await clickRequest(panel.getByRole('button',{name:'Consultar unidades y candidatos'}),'condominium_list');
  const card=panel.locator('article').filter({hasText:prepared.result.candidateRef});
  await card.getByRole('checkbox').check();active.page.once('dialog',d=>d.accept());
  const approved=await clickRequest(card.getByRole('button',{name:'Aprobar relación e identidad'}),'condominium_confirm');
  must(approved.result.status==='confirmed','ui_approval_not_confirmed');await panel.getByRole('status').filter({hasText:'confirmed'}).waitFor();
  pass('ui_server_dev_confirmation',{http:200,status:'confirmed',explicit_synthetic_review:true});
  const {invokeShadowPhase3A}=await import(pathToFileURL(REPO+'/lib/shadow/ai/phase3AGateway.js'));
  const {buildShadowRunIdentityObservability}=await import(pathToFileURL(REPO+'/lib/shadow/runIdentityObservability.js'));
  const tools=[];let modelCalls=0;
  await invokeShadowPhase3A({admin,envelope:{sanitizedText:'Hola, gracias por la información.',providerMetadata:{respondContactId:contactId}},deterministic:{intent:'otro',requiresHuman:true},toolResults:tools,systemPrompt:'fixture',toolGuide:'fixture',
    modelCall:async messages=>{const context=JSON.parse(messages[1].content);must(context.tools[0].result[0].resolved===true&&context.tools[0].result[0].roles.includes('owner')&&context.tools[0].result[1].unitId===unitId&&context.tools[0].result[1].condominiumId===condoId,'real_dev_pre3a_context_missing');modelCalls++;return {text:'{}'};}});
  must(modelCalls===1,'model_call_count_mismatch');pass('real_dev_resolution_before_3a',{model:'SIMULATED',identity:'confirmed',role:'owner',domain:'condominium',unit_resolved:true,model_calls:1});
  const [observation]=buildShadowRunIdentityObservability({runs:[{id:runId,tool_results_json:tools}]});
  must(observation.identityState==='confirmed'&&observation.unitResolved&&observation.relationshipResolved&&!observation.propertyResolved&&!observation.inExactPhone7of7,'observability_mismatch');
  // One explicitly synthetic run fixture stores only the evidence really returned above, not a replay.
  await db.query('begin');
  await db.query("insert into public.shadow_conversations(id,provider,external_conversation_id,contact_hash,channel,first_message_at,last_message_at) values($1,'synthetic',$2,$3,'pr133-local-dev',now(),now())",[conversationId,contactId,digest(contactId)]);
  await db.query("insert into public.shadow_messages(id,conversation_id,provider,external_message_id,direction,occurred_at,sanitized_text,content_hash,provider_metadata) values($1,$2,'synthetic',$3,'inbound',now(),'Hola, gracias por la información.',$4,$5)",[messageId,conversationId,TAG,digest('synthetic'),{fixturePackage:TAG,respondContactId:contactId}]);
  await db.query("insert into public.shadow_ai_runs(id,message_id,status,execution_state,model,prompt_version,schema_version,input_kind,tool_results_json,started_at,completed_at) values($1,$2,'completed','completed','pr133-simulated-model',$3,'synthetic','conversational_message',$4,now(),now())",[runId,messageId,TAG,JSON.stringify(tools)]);
  await db.query('commit');
  const view=active.page.waitForResponse(r=>r.url()===origin+'/api/operaciones/shadow-coordinator'&&r.request().method()==='GET');
  await active.page.reload({waitUntil:'domcontentloaded'});const vr=await view;const v=await vr.json();must(vr.status()===200&&v.ok,'real_observability_endpoint_failed');
  const shown=v.runIdentityObservability.find(r=>r.runId===runId);must(shown&&shown.identityState==='confirmed'&&shown.unitResolved&&shown.relationshipResolved&&!shown.inExactPhone7of7,'real_observability_response_mismatch');
  const observedCard=active.page.locator('article').filter({hasText:'Run '+observation.runRef});await observedCard.waitFor();
  must((await observedCard.innerText()).includes('condominium_owner_admin_review'),'observability_not_visible');
  must(!(v.aiRuns.find(r=>r.id===runId)||{}).tool_results_json,'tool_results_exposed');
  report.observation=shown;pass('real_observability_ui',{http:200,run:observation.runRef,confirmed:true,unit_resolved:true,rental_property:false,historical_7of7:false});
  const denied=await contextFor(actors[1]);await denied.page.goto(origin+'/coordinador-ia-sombra',{waitUntil:'domcontentloaded'});
  await denied.page.getByText('Acceso reservado a Dirección y Coordinación de Operaciones.').waitFor();
  const before=await inventory();
  const response=await denied.page.evaluate(async token=>{const r=await fetch('/api/operaciones/client-reconciliation',{method:'POST',headers:{'content-type':'application/json',Authorization:'Bearer '+token},body:JSON.stringify({action:'condominium_list'})});return {http:r.status,body:await r.json()};},denied.session.access_token);
  must(response.http===403&&response.body.error==='admin_required','nonadmin_not_rejected');must(JSON.stringify(await inventory())===JSON.stringify(before),'nonadmin_side_effect');
  pass('real_nonadmin_rejected',{role:'asesor',http:403,error:'admin_required',ui_action_absent:true,side_effects:0});
  must(apiResponses.filter(x=>x.action==='condominium_prepare').length===1&&apiResponses.filter(x=>x.action==='condominium_confirm').length===1,'unexpected_write_request_count');report.ui_requests=apiResponses;
  active.session.access_token='';denied.session.access_token='';for(const c of contexts)await c.close();
}
async function main(){
  let globalTimer;
  try{
    const ca=await preparation();if(process.argv.includes('--prepare-only'))return;
    await open(DIR+'/integration-fields-attempt.claim','wx',0o600).then(f=>f.close());
    keys=await capture();keys.publicKey=keys.publicKey.trim();keys.adminKey=keys.adminKey.trim();
    must(/^sb_publishable_[A-Za-z0-9_-]+$/.test(keys.publicKey),'public_modern_dev_key_required');must(/^sb_secret_[A-Za-z0-9_-]+$/.test(keys.adminKey),'administrative_modern_dev_key_required');
    report.target_checks=evaluateTarget();emit({stage:'destination_diagnostic',checks:report.target_checks});const badTarget=report.target_checks.find(c=>c.result==='FAIL');if(badTarget)throw fail(badTarget.code);
    const configured=createDevClientConfig(keys.password,ca);credential=configured.credential;db=configured.client;keys.password='';
    // Instance checked above is the exact client used below; no connectionString or SSL URL options.
    const realQuery=db.query.bind(db);db.query=(text,...args)=>{report.last_query=queryMetadata(text);return realQuery(text,...args);};
    db.on('error',e=>{report.connection_error=errorMetadata(e);});
    await db.connect();must(db.connection.stream.authorized===true,'strict_tls_not_authorized');pass('postgres_connected',{project:PROJECT,port:5432,tls_strict:true,hostname_verified:true});
    await catalogAndCollisions();
    const admin=createClient(URLDEV,keys.adminKey,{auth:{persistSession:false,autoRefreshToken:false}});
    const zero=await admin.from('profiles').select('id').limit(0);report.api_validation={endpoint:'profiles limit 0',http:zero.status,error:zero.error?errorMetadata(zero.error):null};must(!zero.error,'dev_admin_api_access_failed');pass('dev_api_access',{sdk:'2.116.0',administrative_key_server_only:true,real_read:true});
    // Native key capture finished. From this point there is a bounded window and guaranteed cleanup.
    globalTimer=setTimeout(()=>{if(server)server.kill('SIGTERM');if(browser)browser.close().catch(()=>{});},15*60000);
    fixtureStart=true;const actors=[];
    for(const [i,role] of ['admin','asesor'].entries()){
      const password=randomBytes(32).toString('base64url');
      const {data,error}=await admin.auth.admin.createUser({email:emails[i],password,email_confirm:true,app_metadata:{fixture_package:TAG}});
      if(error){report.auth_error={role,...errorMetadata(error)};throw fail('synthetic_auth_actor_creation_failed_'+role);}must(data.user?.id,'synthetic_auth_actor_response_missing_'+role);actorIds.push(data.user.id);
      await db.query("update public.profiles set role_id=$2,role=$3,active=true,full_name='PR133 SYNTHETIC INTEGRATION',participa_kpis=false where id=$1 and email=$4",[data.user.id,role,role==='admin'?'admin':'staff',emails[i]]);
      const profile=(await db.query('select role_id,active from public.profiles where id=$1',[data.user.id])).rows[0];precheck('synthetic_profile_missing','own '+role+' profile',true,Boolean(profile),Boolean(profile));precheck('synthetic_profile_role_mismatch','own '+role+' role',role,profile.role_id,profile.role_id===role);precheck('synthetic_profile_inactive','own '+role+' active',true,profile.active,profile.active===true);actors.push({id:data.user.id,email:emails[i],password,role});
    }
    await db.query('begin');await db.query('insert into public.condominios(id,nombre,activo) values($1,$2,true)',[condoId,TAG]);
    await db.query("insert into public.unidades_condominio(id,condominio_id,numero,activo,propietario_telefono,propietario_nombre) values($1,$2,$3,true,$4,'PR133 SYNTHETIC ONLY')",[unitId,condoId,TAG,phone]);await db.query('commit');
    pass('synthetic_fixtures_ready',{auth_actors:2,roles:['admin','asesor'],condominiums:1,units:1,emails_sent:0});
    await runUi(admin,await startServer(),actors);await assertNoAdminKeyInBrowserArtifacts();actors.forEach(a=>a.password='');report.integration='PASS';
  }catch(e){report.integration='NOT_COMPLETED';report.error={...errorMetadata(e),after_stage:report.steps.at(-1)?.stage||'preparation',timeout:e?.name==='TimeoutError'};emit({stage:'stopped',...report.error});}
  finally{
    clearTimeout(globalTimer);if(browser)await browser.close().catch(()=>{});
    if(server){server.kill('SIGTERM');await Promise.race([new Promise(ok=>server.once('exit',ok)),delay(8000)]);if(server.exitCode===null)server.kill('SIGKILL');}
    try{await cleanup();}catch(e){emit({stage:'cleanup_failed',...safeError(e)});}
    if(db)await db.end().catch(()=>{});if(credential)credential.password='';if(keys){keys.adminKey='';keys.publicKey='';keys.password='';}
    if(createdDependencyLink&&await lstat(REPO+'/node_modules').then(s=>s.isSymbolicLink()).catch(()=>false))await unlink(REPO+'/node_modules');
    report.finished_at=new Date().toISOString();report.result=report.integration==='PASS'&&report.cleanup.result==='PASS'?'INTEGRATION_DEV_PASS':'PENDING_OR_FAILED';
    if(!process.argv.includes('--prepare-only')){await writeFile(DIR+'/integration-fields-report.json',JSON.stringify(report,null,2)+'\n',{mode:0o600});emit({result:report.result,report:DIR+'/integration-fields-report.json'});}
  }
}
if(process.argv[1]===fileURLToPath(import.meta.url))main();
