import test from 'node:test';
import assert from 'node:assert/strict';
import {evaluatePostgresContext,checkMetadata,evaluateTarget,queryMetadata,OFFICIAL_DEV_ROUTE,composeDevCredential,createDevClientConfig} from './run-integration.mjs';
const row={db_role:'postgres',db:'postgres',backend_ssl:true};
const tls={encrypted:true,authorized:true,hostname_verified:true};
test('all three current checks and original observations are retained on PASS',()=>{
  const r=evaluatePostgresContext(row,tls);assert.equal(r.passed,true);assert.equal(r.checks.length,3);assert.equal(r.original_conditions.length,3);assert.deepEqual(r.failed_codes,[]);
  assert.ok(r.checks.every(c=>Object.hasOwn(c,'expected')&&Object.hasOwn(c,'observed')&&c.source));
});
for(const [field,value,code] of [['db_role','synthetic_role','postgres_role_mismatch'],['db','synthetic_db','postgres_database_mismatch']]){
  test('isolated '+code,()=>{const r=evaluatePostgresContext({...row,[field]:value},tls);assert.equal(r.passed,false);assert.deepEqual(r.failed_codes,[code]);assert.equal(r.checks.filter(c=>c.result==='FAIL').length,1);assert.equal(r.checks.length,3);assert.ok(JSON.stringify(r).includes(value));});
}
for(const k of Object.keys(tls))test('isolated client TLS '+k,()=>{
  const r=evaluatePostgresContext(row,{...tls,[k]:false});assert.equal(r.passed,false);assert.deepEqual(r.failed_codes,['client_tls_'+k+'_failed']);assert.equal(r.checks.length,3);assert.equal(r.checks[2].observed[k],false);
});
test('all failures retained, not short-circuited',()=>{
  const r=evaluatePostgresContext({db_role:'synthetic',db:'other',backend_ssl:false},{encrypted:false,authorized:false,hostname_verified:false});
  assert.equal(r.checks.filter(c=>c.result==='FAIL').length,3);assert.equal(r.failed_codes.length,5);assert.equal(r.original_conditions.filter(c=>c.result==='FAIL').length,3);
});
test('backend SSL false retained explicitly; never substituted for client TLS',()=>{
  const r=evaluatePostgresContext({...row,backend_ssl:false},tls);assert.equal(r.original_conditions[2].observed,false);assert.equal(r.original_conditions[2].result,'FAIL');assert.equal(r.original_conditions[2].code,'backend_ssl_not_true');assert.equal(r.original_conditions[2].required_for_client_tls,false);assert.equal(r.passed,true);
});
test('backend SSL true cannot mask unauthorized client',()=>{
  const r=evaluatePostgresContext(row,{...tls,authorized:false});assert.equal(r.passed,false);assert.equal(r.checks[2].result,'FAIL');
});
test('missing values remain null and checks fail closed',()=>{
  const r=evaluatePostgresContext();assert.equal(r.passed,false);assert.equal(r.checks[0].observed,null);assert.equal(r.original_conditions[2].observed,null);assert.equal(r.checks.length,3);
});
test('only explicitly selected safe metadata is emitted',()=>{
  const r=evaluatePostgresContext({...row,password:'SYNTHETIC_SECRET',token:'SYNTHETIC_TOKEN'}, {...tls,connectionString:'DO_NOT_PRINT'});
  assert.ok(!/SYNTHETIC_SECRET|SYNTHETIC_TOKEN|DO_NOT_PRINT/.test(JSON.stringify(r)));
});
test('generic metadata recorder preserves expected observed object for each failure',()=>{
  const rows=[];checkMetadata(rows,'missing_column','public.synthetic',['id','user_id'],['id'],false);checkMetadata(rows,'delete_denied','auth.synthetic',true,false,false);
  assert.equal(rows.length,2);assert.equal(rows[0].code,'missing_column');assert.deepEqual(rows[0].expected,['id','user_id']);assert.deepEqual(rows[0].observed,['id']);assert.equal(rows[1].result,'FAIL');
});
test('official target all six fields retained, frozen and without secrets',()=>{assert.ok(Object.isFrozen(OFFICIAL_DEV_ROUTE));assert.equal(evaluateTarget().length,6);assert.ok(evaluateTarget().every(c=>c.result==='PASS'));});
for(const [field,value,code] of [['port',6543,'pooler_port_mismatch'],['project','syntheticwrongproject','pooler_project_mismatch'],['user','postgres.syntheticwrongproject','pooler_project_user_mismatch'],['database','other','pooler_database_mismatch'],['host','aws-0-eu-west-1.pooler.supabase.com','pooler_host_mismatch'],['mode','direct','pooler_mode_mismatch']])test('target '+code,()=>{
  const changed={...OFFICIAL_DEV_ROUTE,[field]:value};
  const r=evaluateTarget(changed);assert.ok(r.some(c=>c.code===code&&c.result==='FAIL'));assert.equal(r.length,6);
  assert.throws(()=>composeDevCredential('synthetic-password',changed),e=>e.safeCode===code);
});
test('additional route properties including URI or SSL overrides are rejected',()=>{
  for(const extra of [{connectionString:'synthetic-uri'},{ssl:{rejectUnauthorized:false}},{password:'SYNTHETIC_SECRET'},{options:'synthetic'}])assert.throws(()=>composeDevCredential('synthetic-password',{...OFFICIAL_DEV_ROUTE,...extra}),e=>e.safeCode==='unexpected_route_option');
});
test('target diagnostic only selects nonsecret route fields',()=>{
  const r=evaluateTarget({...OFFICIAL_DEV_ROUTE,password:'SYNTHETIC_SECRET',connectionString:'DO_NOT_PRINT',token:'DO_NOT_PRINT'});assert.ok(!/SYNTHETIC_SECRET|DO_NOT_PRINT/.test(JSON.stringify(r)));
});
const specialPasswords=['synthetic-simple','@:/?#[]%+&=synthetic','  synthetic whitespace  ','synthetic%40literal%25','sintético-ñ-漢字-🔒','synthetic\\quote\"\'dollar$`','synthetic\r\nline','[YOUR-PASSWORD]'];
specialPasswords.forEach((password,i)=>test('separate password remains byte-exact through pg client, synthetic case '+(i+1),()=>{
  const ca={pem:'SYNTHETIC_CA_NO_CONNECTION'};
  const {credential,config,client}=createDevClientConfig(password,ca);
  assert.equal(credential.password,password);assert.equal(config.password,password);assert.equal(client.connectionParameters.password,password);
  for(const [key,expected] of [['host',OFFICIAL_DEV_ROUTE.host],['port',5432],['user',OFFICIAL_DEV_ROUTE.user],['database','postgres']])assert.equal(client.connectionParameters[key],expected);
  assert.equal(config.ssl.ca,ca.pem);assert.equal(client.connection.ssl.rejectUnauthorized,true);assert.equal(client.connection.ssl.servername,OFFICIAL_DEV_ROUTE.host);
  assert.equal(Object.hasOwn(config,'connectionString'),false);assert.equal(Object.hasOwn(client.connection.ssl,'checkServerIdentity'),false);
  assert.equal(client._connecting,false);assert.equal(client._connected,false);
}));
test('missing password and NUL have specific codes without exposing values',()=>{
  for(const value of ['',undefined,null])assert.throws(()=>composeDevCredential(value),e=>e.safeCode==='postgres_password_missing');
  assert.throws(()=>composeDevCredential('synthetic\0secret'),e=>e.safeCode==='postgres_password_nul_rejected'&&!e.message.includes('secret'));
});
test('SQL diagnostic contains only verb and object, no literal or arguments',()=>{
  assert.deepEqual(queryMetadata("select * from auth.users where email='DO_NOT_PRINT'"),{command:'SELECT',objects:['auth.users']});
});
