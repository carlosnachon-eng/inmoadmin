// Temporary test process only: real application, real DEV Supabase; one synthetic Respond contact.
// Receives server credentials over private stdin, never argv/files. No product source changes.
const fs = require('node:fs');
const next = require('/Users/carlos/Documents/ChatGPT/inmoadmin/fase-3c-canonical-identity-resolution/node_modules/next');
const http = require('node:http');
const DEV = 'hjfwjnejbcpmknvfpdcq.supabase.co';
let bytes=''; process.stdin.setEncoding('utf8'); process.stdin.on('data',c=>bytes+=c);
process.stdin.on('end',async()=>{
  let server,app,stage='configuration';
  try {
    const config=JSON.parse(bytes); bytes='';
    if(config.project!=='hjfwjnejbcpmknvfpdcq'||!config.adminKey.startsWith('sb_secret_')||!config.publicKey.startsWith('sb_publishable_'))throw Error('configuration_rejected');
    for(const key of Object.keys(process.env))if(/SUPABASE|RESPOND|ANTHROPIC|SHADOW|VERCEL|NEXT_PUBLIC/.test(key))delete process.env[key];
    Object.assign(process.env,{NODE_ENV:'development',NEXT_TELEMETRY_DISABLED:'1',NEXT_PUBLIC_SUPABASE_URL:`https://${DEV}`,NEXT_PUBLIC_SUPABASE_ANON_KEY:config.publicKey,
      SUPABASE_SERVICE_ROLE_KEY:config.adminKey,RESPOND_IO_TOKEN:'pr133-synthetic-mock-only',SHADOW_CLIENT_RECONCILIATION_PREPARE_ENABLED:'true',
      SHADOW_CLIENT_RECONCILIATION_WRITE_ENABLED:'true',SHADOW_IDENTITY_CONFIRMATION_ENABLED:'true',SHADOW_ADMIN_OUTBOUND_ENABLED:'false',SHADOW_OUTBOUND_ENABLED:'false',
      SHADOW_ADMIN_WORK_R1_ENABLED:'false',SHADOW_ADMIN_OUTBOUND_CANARY_ENABLED:'false',SHADOW_CANARY_ENABLED:'false'});
    const realFetch=globalThis.fetch;
    globalThis.fetch=async(input,init={})=>{
      const url=new URL(typeof input==='string'||input instanceof URL?input:input.url),method=(init.method||input.method||'GET').toUpperCase();
      if(url.hostname==='api.respond.io') {
        if(method!=='GET'||url.pathname!==`/v2/contact/id:${config.contactId}`||url.search)throw Error('respond_fixture_scope_violation');
        process.stdout.write(JSON.stringify({stage:'respond_mock',method:'GET'})+'\n');
        return new Response(JSON.stringify({id:config.contactId,phone:config.phone}),{status:200,headers:{'content-type':'application/json'}});
      }
      if(url.protocol==='https:'&&url.hostname===DEV) {
        const allowed=method==='GET'||method==='HEAD'||(method==='POST'&&url.pathname==='/rest/v1/rpc/review_condominium_owner_identity');
        if(!allowed)throw Error('unexpected_server_dev_write');
        const response=await realFetch(input,init);
        if(url.pathname==='/auth/v1/user'||url.pathname==='/rest/v1/profiles'||url.pathname.startsWith('/rest/v1/rpc/'))
          process.stdout.write(JSON.stringify({stage:'real_dev_response',path:url.pathname,method,http:response.status})+'\n');
        return response;
      }
      if(url.hostname==='127.0.0.1'||url.hostname==='localhost')return realFetch(input,init);
      throw Error('external_network_not_authorized');
    };
    // All output is replaced with metadata only; do not forward raw Next/SDK logs.
    console.log=()=>{};console.error=()=>{};console.warn=()=>{};
    stage='next_prepare';app=next({dev:true,dir:config.repo,hostname:'127.0.0.1',port:config.port}); await app.prepare();
    server=http.createServer(app.getRequestHandler());
    stage='listen';server.on('error',e=>process.stdout.write(JSON.stringify({stage:'server_start_failed',at:stage,code:/^[A-Z0-9_]+$/.test(e.code||'')?e.code:'server_error'})+'\n'));
    server.listen(config.port,'127.0.0.1',()=>process.stdout.write(JSON.stringify({stage:'local_ready',address:server.address().address,port:server.address().port})+'\n'));
    const stop=async()=>{if(server)server.close();if(app)await app.close();process.exit(0);};
    process.on('SIGTERM',stop);process.on('SIGINT',stop);
  }catch(e){process.stdout.write(JSON.stringify({stage:'server_start_failed',at:stage,code:/^[A-Z0-9_]+$/.test(e.code||'')?e.code:'server_start_error'})+'\n');process.exitCode=1;}
});
