-- PR #133 HEAD e0cdda009dc1d9fbb92ccd67b1977bc18ab7d8bf
-- SOLO inmoadmin-dev / hjfwjnejbcpmknvfpdcq. Verificar proyecto en UI antes de ejecutar.
-- Prueba sintetica, NO migracion. No ejecutar en Produccion.
begin;
set local statement_timeout='40s';
set local lock_timeout='5s';
set local idle_in_transaction_session_timeout='45s';
create temporary table pr133_results(check_name text primary key, result text not null) on commit drop;
create or replace function pg_temp.pr133_id(n integer) returns uuid language sql immutable as $$
 select ('133c2026-0918-4000-8000-'||lpad(n::text,12,'0'))::uuid $$;
create or replace function pg_temp.pr133_phone(n integer) returns text language sql immutable as $$
 select '52000013'||lpad(n::text,4,'0') $$;
create or replace function pg_temp.pr133_contact(n integer) returns text language sql immutable as $$
 select 'pr133-dev-synthetic-20260920-'||n::text $$;
create or replace function pg_temp.pr133_assert(v boolean,label text) returns void language plpgsql as $$
begin
 if v is distinct from true then raise exception 'PR133 ASSERT FAILED: %',label; end if;
 insert into pg_temp.pr133_results values(label,'PASS');
end $$;
grant select,insert on pr133_results to anon,authenticated,service_role;
-- Actores Auth exclusivamente sinteticos en 01/02; sin login, roles nuevos ni permisos del negocio.
create or replace function pg_temp.pr133_unit(n integer, phone_n integer default null, condo_n integer default 20, active_value boolean default true)
returns void language plpgsql as $$
begin
 insert into public.unidades_condominio(id,condominio_id,numero,activo,propietario_telefono,propietario_nombre)
 values(pg_temp.pr133_id(n),pg_temp.pr133_id(condo_n),'PR133-'||n,active_value,pg_temp.pr133_phone(coalesce(phone_n,n)),'PR133 SYNTHETIC ONLY');
end $$;
create or replace function pg_temp.pr133_call(n integer, action_name text, candidate uuid default null,
 phone_n integer default null, actor_n integer default 1, contact_n integer default null,
 attach_identity boolean default false, observed_at timestamptz default clock_timestamp())
returns jsonb language sql as $$
 select public.review_condominium_owner_identity(action_name,pg_temp.pr133_id(n),
 pg_temp.pr133_contact(coalesce(contact_n,n)),pg_temp.pr133_id(actor_n),
 encode(extensions.digest(pg_temp.pr133_phone(coalesce(phone_n,n)),'sha256'),'hex'),
 observed_at,candidate,null,attach_identity) $$;

-- Read-only de datos; objetos TEMP solo para assertions. No RPC.
do $$ begin
 perform pg_temp.pr133_assert(
  (select count(*) from public.respond_identity_links where respond_contact_id=pg_temp.pr133_contact(401)
   and link_source='condominium_owner_admin_review' and link_status='confirmed')=1,'same contact exactly one link');
 perform pg_temp.pr133_assert(
  (select count(*) from public.client_identity_audit a join public.client_reconciliation_candidates c on c.id=a.candidate_id
   where c.respond_contact_id=pg_temp.pr133_contact(401) and a.event_type='confirmed')=1,'same contact exactly one confirmation audit');
 perform pg_temp.pr133_assert(
  (select count(*) from public.respond_identity_links where client_identity_id=pg_temp.pr133_id(500)
   and link_status='confirmed')=1,'two contacts exactly one identity winner');
 perform pg_temp.pr133_assert(
  (select count(*) from public.client_reconciliation_candidates
   where respond_contact_id in(pg_temp.pr133_contact(501),pg_temp.pr133_contact(502))
    and candidate_status='confirmed')=1,'one candidate confirmed in identity race');
 perform pg_temp.pr133_assert(
  exists(select 1 from public.client_identity_audit a join public.client_reconciliation_candidates c on c.id=a.candidate_id
   where c.respond_contact_id=pg_temp.pr133_contact(502) and a.event_type='rejected'
    and a.context_ids->>'reasonCode'='respond_identity_conflict'),'loser rejection audit present');
 perform pg_temp.pr133_assert(
  not exists(select 1 from public.respond_identity_links where respond_contact_id=pg_temp.pr133_contact(502)
   and link_status='confirmed'),'loser no confirmed link');
 perform pg_temp.pr133_assert(
  not exists(select 1 from public.client_identity_audit where actor_profile_id=pg_temp.pr133_id(1)
   and (context_ids::text like '%52000013%' or context_ids::text like '%SYNTHETIC%')),'fixture audit contains no raw phone or name');
end $$;
select check_name,result from pr133_results order by check_name;
rollback;
select 'PR133 persisted race invariants PASS; overlap requires both A/B transcripts' as result;
