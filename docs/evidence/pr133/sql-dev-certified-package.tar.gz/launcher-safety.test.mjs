import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import {PROJECT,HEAD,FILES,parseCredential,clientConfig,safeError,loadSql,splitSetup,safeRows,executeBlock} from './run-dev-certification.mjs';

const syntheticPassword='synthetic-local-test-only';
const direct=`postgresql://postgres:${syntheticPassword}@db.${PROJECT}.supabase.co:5432/postgres`;
test('only DEV direct route accepted',()=>{
 const c=parseCredential(direct);assert.equal(c.mode,'direct');assert.equal(c.host,`db.${PROJECT}.supabase.co`);
 assert.equal(c.password,syntheticPassword);
});
test('official session pooler requires exact DEV tenant user and 5432',()=>{
 const c=parseCredential(`postgresql://postgres.${PROJECT}:${syntheticPassword}@aws-0-us-east-1.pooler.supabase.com:5432/postgres`);
 assert.equal(c.mode,'session_pooler');
});
test('production, nonofficial hosts, transaction pooler, and alternate databases rejected',()=>{
 for(const u of [direct.replace(PROJECT,'bnzrnizrmonjxlktbhlp'),direct.replace('5432','6543'),direct.replace('/postgres','/other'),
  direct.replace(`db.${PROJECT}.supabase.co`,'127.0.0.1'),direct.replace(`db.${PROJECT}.supabase.co`,'db.evil.example'),
  `postgresql://postgres.other:${syntheticPassword}@aws-0-us-east-1.pooler.supabase.com:5432/postgres`,direct+'#fragment'])
  assert.throws(()=>parseCredential(u));
});
test('connection options cannot disable TLS or override destination',()=>{
 for(const option of ['sslmode=disable','sslmode=prefer','host=evil.example','options=-c%20role%3Dadmin','sslrootcert=other'])
  assert.throws(()=>parseCredential(direct+'?'+option));
 const config=clientConfig(parseCredential(direct+'?sslmode=require'),{pem:'synthetic-ca-for-config-test'});
 assert.equal(config.ssl.rejectUnauthorized,true);assert.equal(config.ssl.servername,`db.${PROJECT}.supabase.co`);
 assert.equal(config.ssl.minVersion,'TLSv1.2');assert.equal(config.connectionString,undefined);
});
test('empty or placeholder credentials rejected',()=>{
 assert.throws(()=>parseCredential(direct.replace(syntheticPassword,'')));
 assert.throws(()=>parseCredential(direct.replace(syntheticPassword,'[YOUR-PASSWORD]')));
});
test('driver errors never echo URI/password/details/stack',()=>{
 const e=Object.assign(new Error(direct),{code:'28P01',detail:syntheticPassword,where:direct});
 assert.deepEqual(safeError(e),{code:'28P01'});
 assert.ok(!JSON.stringify(safeError(e)).includes(syntheticPassword));
});
test('SQL assets remain exactly the eight certified hashes; no migrations imported',async()=>{
 const sql=await loadSql();assert.equal(Object.keys(sql).length,8);assert.deepEqual(Object.keys(sql),Object.keys(FILES));
 assert.ok(!Object.keys(sql).some(x=>x.includes('migration')||x.includes('_checks')));
});
test('setup is split only at its single outer commit; no bootstrap adaptation',async()=>{
 const sql=await loadSql();const [pre,commit]=splitSetup(sql['02_concurrency_setup.sql']);
 assert.equal(pre+commit,sql['02_concurrency_setup.sql']);assert.ok(pre.startsWith('-- PR #133 HEAD '+HEAD));
 assert.match(commit,/^commit;/);assert.throws(()=>splitSetup('no commit'));
});
test('runtime records only sanitized assertion and race columns',()=>{
 const rows=safeRows({rows:[{phone:'private',password:'private'},{check_name:'fixture','result':'PASS',token:'private'},
  {race:'identity',worker:'B',backend_pid:2,status:'rejected',reason:'respond_identity_conflict',duration_ms:'3.1',payload:'private'}]});
 assert.equal(rows.length,2);assert.doesNotMatch(JSON.stringify(rows),/private|token|password/);
});
test('launcher has strict bounded execution, cleanup, no browser or secret extraction',async()=>{
 const code=await readFile(new URL('./run-dev-certification.mjs',import.meta.url),'utf8');
 assert.match(code,/with hidden answer/);assert.match(code,/dev-attempt.claim.*'wx'/);
 assert.match(code,/setTimeout\(abort,180000\)/);assert.match(code,/commitAttempted && manifest && observer/);
 assert.doesNotMatch(code,/rejectUnauthorized\s*:\s*false|readFile\([^\n]*(?:\.env|auth\.json)|db push|initdb|EmbeddedPostgres/);
});

// Orchestration tests only: explicit fake PostgreSQL clients; NOT evidence from DEV.
async function simulate({collision=false,workerFail=false,cleanupFail=false}={}) {
 const sql=await loadSql(),[body,commit]=splitSetup(sql['02_concurrency_setup.sql']);
 const manifest=Object.entries({'auth.users':3,profiles:3,condominios:2,unidades_condominio:3,client_reconciliation_candidates:3,client_identities:1})
  .flatMap(([kind,n])=>Array.from({length:n},(_,i)=>({kind,id:`synthetic-${kind}-${i}`})));
 let records=collision?manifest:[],pid=10;const calls=[];
 const openClient=async()=>{const certPid=++pid;return {certPid,connection:{stream:{destroy(){}}},end:async()=>{},
  query:async(text)=>{
   if(text==='rollback')return {rows:[]};
   if(text.startsWith('with candidates'))return {rows:[...records]};
   if(text.includes('pg_stat_activity s join pg_locks'))return {rows:[{ready:true}]};
   if(text===body){calls.push('setup-body');records=manifest;return {rows:[]};}
   if(text===commit){calls.push('setup-commit');return {rows:[]};}
   const name=Object.keys(sql).find(n=>sql[n]===text);if(!name)throw new Error('unexpected mock SQL');calls.push(name);
   if(name==='04_same_contact_B.sql'&&workerFail)throw Object.assign(new Error('test worker failed'),{code:'P0001'});
   if(name==='08_cleanup.sql'){if(cleanupFail)throw Object.assign(new Error('PR133 cleanup dependency'),{code:'P0001'});records=[];return {rows:[]};}
   if(/^(03|04|05|06)_/.test(name)){
    const worker=/_(A)\.sql$/.test(name)?'A':'B',race=name.includes('identity')?'identity':'contact';
    return {rows:[{race,worker,backend_pid:certPid,status:worker==='A'?'confirmed':race==='contact'?'already_confirmed':'rejected',
     reason:race==='identity'&&worker==='B'?'respond_identity_conflict':null,duration_ms:1},
     ...(worker==='A'?[{check_name:'independent B connection observed blocked by A',result:'PASS'}]:[])]};
   }
   return {rows:[]};
  }};};
 const report={tests:[],races:[]};await executeBlock({openClient,sql,report,emit(){}});return {report,calls,manifest};
}
test('simulated orchestration: one pass, independent workers, cleanup once',async()=>{
 const {report,calls}=await simulate();assert.equal(report.database_tests,'PASS');assert.equal(report.cleanup.result,'PASS');
 assert.equal(report.races.length,2);assert.equal(calls.filter(x=>x==='08_cleanup.sql').length,1);
 assert.equal(calls.filter(x=>x==='01_behavioral_rollback.sql').length,1);
});
test('simulated collision: no fixture creation and no deletion of preexisting records',async()=>{
 const {report,calls}=await simulate({collision:true});assert.equal(calls.length,0);
 assert.equal(report.cleanup.result,'NOT_NEEDED_NO_WRITES');assert.ok(report.preexisting_fixture_refs.length);
});
test('simulated worker failure: no retry or second race; own fixtures still cleaned',async()=>{
 const {report,calls}=await simulate({workerFail:true});assert.equal(report.database_tests,'FAIL_OR_BLOCKED');
 assert.equal(report.cleanup.result,'PASS');assert.ok(!calls.includes('05_same_identity_A.sql'));
 assert.equal(calls.filter(x=>x==='04_same_contact_B.sql').length,1);
});
test('simulated cleanup failure: reports remaining fixture identifiers, never clean',async()=>{
 const {report,manifest}=await simulate({cleanupFail:true});assert.equal(report.cleanup.result,'FAIL');
 assert.deepEqual(report.cleanup.remaining,manifest);
});
