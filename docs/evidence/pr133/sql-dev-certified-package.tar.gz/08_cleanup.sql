-- PR #133 HEAD e0cdda009dc1d9fbb92ccd67b1977bc18ab7d8bf
-- SOLO inmoadmin-dev / hjfwjnejbcpmknvfpdcq. Verificar proyecto en UI antes de ejecutar.
-- Prueba sintetica, NO migracion. No ejecutar en Produccion.
begin;
set local statement_timeout='40s';
set local lock_timeout='5s';
set local idle_in_transaction_session_timeout='45s';
create temporary table pr133_results(check_name text primary key, result text not null) on commit drop;
create or replace function pg_temp.pr133_id(n integer) returns uuid language sql immutable as $$
 select ('133c2026-0918-4000-8000-'||lpad(n::text,12,'0'))::uuid $$;
create or replace function pg_temp.pr133_phone(n integer) returns text language sql immutable as $$
 select '52000013'||lpad(n::text,4,'0') $$;
create or replace function pg_temp.pr133_contact(n integer) returns text language sql immutable as $$
 select 'pr133-dev-synthetic-20260920-'||n::text $$;
create or replace function pg_temp.pr133_assert(v boolean,label text) returns void language plpgsql as $$
begin
 if v is distinct from true then raise exception 'PR133 ASSERT FAILED: %',label; end if;
 insert into pg_temp.pr133_results values(label,'PASS');
end $$;
grant select,insert on pr133_results to anon,authenticated,service_role;
-- Actores Auth exclusivamente sinteticos en 01/02; sin login, roles nuevos ni permisos del negocio.
create or replace function pg_temp.pr133_unit(n integer, phone_n integer default null, condo_n integer default 20, active_value boolean default true)
returns void language plpgsql as $$
begin
 insert into public.unidades_condominio(id,condominio_id,numero,activo,propietario_telefono,propietario_nombre)
 values(pg_temp.pr133_id(n),pg_temp.pr133_id(condo_n),'PR133-'||n,active_value,pg_temp.pr133_phone(coalesce(phone_n,n)),'PR133 SYNTHETIC ONLY');
end $$;
create or replace function pg_temp.pr133_call(n integer, action_name text, candidate uuid default null,
 phone_n integer default null, actor_n integer default 1, contact_n integer default null,
 attach_identity boolean default false, observed_at timestamptz default clock_timestamp())
returns jsonb language sql as $$
 select public.review_condominium_owner_identity(action_name,pg_temp.pr133_id(n),
 pg_temp.pr133_contact(coalesce(contact_n,n)),pg_temp.pr133_id(actor_n),
 encode(extensions.digest(pg_temp.pr133_phone(coalesce(phone_n,n)),'sha256'),'hex'),
 observed_at,candidate,null,attach_identity) $$;

-- Exclusivamente fixtures de 02..07. Nunca borrar datos ajenos ni usar CASCADE.
create temporary table pr133_candidates on commit drop as
 select id,client_identity_id from public.client_reconciliation_candidates
 where respond_contact_id in(pg_temp.pr133_contact(401),pg_temp.pr133_contact(501),pg_temp.pr133_contact(502))
 and evidence_version='condominium_owner_review_v1';
create temporary table pr133_identities on commit drop as
 select pg_temp.pr133_id(500) id union select client_identity_id from pr133_candidates where client_identity_id is not null;
create temporary table pr133_links on commit drop as
 select id from public.respond_identity_links
 where respond_contact_id in(pg_temp.pr133_contact(401),pg_temp.pr133_contact(501),pg_temp.pr133_contact(502));
do $$
begin
 if current_user<>'postgres' then raise exception 'PR133 cleanup requires DEV SQL Editor postgres role'; end if;
 if exists(select 1 from auth.users where id in(pg_temp.pr133_id(1),pg_temp.pr133_id(2),pg_temp.pr133_id(3))
   and (raw_app_meta_data is distinct from '{"fixture_package":"pr133-dev-20260920"}'::jsonb
    or email is distinct from case id when pg_temp.pr133_id(1) then 'pr133.admin@example.invalid'
     when pg_temp.pr133_id(2) then 'pr133.nonadmin@example.invalid' else 'pr133.inactive@example.invalid' end
    or encrypted_password is not null or last_sign_in_at is not null or invited_at is not null
    or banned_until is distinct from 'infinity'::timestamptz)) then
  raise exception 'PR133 cleanup Auth ownership mismatch'; end if;
 if exists(select 1 from public.condominios where id in(pg_temp.pr133_id(20),pg_temp.pr133_id(21))
   and nombre is distinct from case id when pg_temp.pr133_id(20) then 'PR133 SYNTHETIC CONDOMINIUM 20'
    else 'PR133 SYNTHETIC CONDOMINIUM 21' end) then
  raise exception 'PR133 cleanup condominium ownership mismatch'; end if;
 if exists(select 1 from public.profiles where id in(pg_temp.pr133_id(1),pg_temp.pr133_id(2),pg_temp.pr133_id(3))
   and (full_name is distinct from 'PR133 SYNTHETIC ONLY' or email not in
    ('pr133.admin@example.invalid','pr133.nonadmin@example.invalid','pr133.inactive@example.invalid'))) then
  raise exception 'PR133 cleanup profile ownership mismatch'; end if;
 if exists(select 1 from public.unidades_condominio where id in(pg_temp.pr133_id(401),pg_temp.pr133_id(501),pg_temp.pr133_id(502))
   and (condominio_id is distinct from pg_temp.pr133_id(20) or propietario_nombre is distinct from 'PR133 SYNTHETIC ONLY'
    or propietario_telefono is distinct from pg_temp.pr133_phone(case when id=pg_temp.pr133_id(401) then 401 else 500 end))) then
  raise exception 'PR133 cleanup unit ownership mismatch'; end if;
 if exists(select 1 from public.client_identities where id in(select id from pr133_identities)
   and (auth_user_id is not null or phone_digest not in(
    encode(extensions.digest(pg_temp.pr133_phone(401),'sha256'),'hex'),
    encode(extensions.digest(pg_temp.pr133_phone(500),'sha256'),'hex')))) then
  raise exception 'PR133 cleanup identity ownership mismatch'; end if;
 if exists(select 1 from public.client_source_links where client_identity_id in(select id from pr133_identities)
   and (source_type<>'condominium_unit_owner' or source_id not in(pg_temp.pr133_id(401),pg_temp.pr133_id(501),pg_temp.pr133_id(502))))
 or exists(select 1 from public.respond_identity_links where client_identity_id in(select id from pr133_identities)
   and respond_contact_id not in(pg_temp.pr133_contact(401),pg_temp.pr133_contact(501),pg_temp.pr133_contact(502)))
 or exists(select 1 from public.client_reconciliation_candidates where client_identity_id in(select id from pr133_identities)
   and id not in(select id from pr133_candidates))
 or exists(select 1 from public.client_reconciliation_candidate_sources where source_type='condominium_unit_owner'
   and source_id in(pg_temp.pr133_id(401),pg_temp.pr133_id(501),pg_temp.pr133_id(502))
   and candidate_id not in(select id from pr133_candidates)) then
  raise exception 'PR133 cleanup found nonfixture relationship; no deletion permitted'; end if;
end $$;
-- Refuse accidental cascading deletes: inspect EVERY FK before deleting a parent.
create or replace function pg_temp.pr133_no_children(parent_table regclass, targets uuid[])
returns void language plpgsql as $$
declare r record; child_col text; n bigint;
begin
 for r in select * from pg_constraint where contype='f' and confrelid=parent_table loop
  if cardinality(r.conkey)<>1 or cardinality(r.confkey)<>1 then
   raise exception 'PR133 cleanup unsupported composite dependency: %',r.conname; end if;
  select ca.attname into child_col
   from unnest(r.conkey,r.confkey) k(child_att,parent_att)
   join pg_attribute pa on pa.attrelid=r.confrelid and pa.attnum=k.parent_att
   join pg_attribute ca on ca.attrelid=r.conrelid and ca.attnum=k.child_att
   where pa.attname='id';
  if child_col is null then raise exception 'PR133 unsupported FK for cleanup: %',r.conname; end if;
  execute format('select count(*) from %s where %I=any($1)',r.conrelid::regclass,child_col) into n using targets;
  if n<>0 then raise exception 'PR133 cleanup remaining dependency: %; no cascade allowed',r.conname; end if;
 end loop;
end $$;
-- Synthetic audit only: expected cleanup explicitly authorized for these fixtures.
delete from public.respond_identity_audit where actor_profile_id=pg_temp.pr133_id(1)
 and respond_contact_id in(pg_temp.pr133_contact(401),pg_temp.pr133_contact(501),pg_temp.pr133_contact(502));
select pg_temp.pr133_no_children('public.respond_identity_links',(select array_agg(id) from pr133_links));
delete from public.respond_identity_links where id in(select id from pr133_links)
 and link_source='condominium_owner_admin_review' and confirmed_by=pg_temp.pr133_id(1);
delete from public.client_identity_audit where actor_profile_id=pg_temp.pr133_id(1)
 and (candidate_id in(select id from pr133_candidates)
  or context_ids->>'unitId' in(pg_temp.pr133_id(401)::text,pg_temp.pr133_id(501)::text,pg_temp.pr133_id(502)::text));
delete from public.client_reconciliation_candidate_sources where candidate_id in(select id from pr133_candidates)
 and source_type='condominium_unit_owner'
 and source_id in(pg_temp.pr133_id(401),pg_temp.pr133_id(501),pg_temp.pr133_id(502));
select pg_temp.pr133_no_children('public.client_reconciliation_candidates',(select array_agg(id) from pr133_candidates));
delete from public.client_reconciliation_candidates where id in(select id from pr133_candidates);
delete from public.client_source_links where client_identity_id in(select id from pr133_identities)
 and source_type='condominium_unit_owner'
 and source_id in(pg_temp.pr133_id(401),pg_temp.pr133_id(501),pg_temp.pr133_id(502))
 and confirmed_by=pg_temp.pr133_id(1);
delete from public.client_identity_roles where client_identity_id in(select id from pr133_identities);
select pg_temp.pr133_no_children('public.client_identities',(select array_agg(id) from pr133_identities));
delete from public.client_identities where id in(select id from pr133_identities);
select pg_temp.pr133_no_children('public.unidades_condominio',array[pg_temp.pr133_id(401),pg_temp.pr133_id(501),pg_temp.pr133_id(502)]);
delete from public.unidades_condominio where id in(pg_temp.pr133_id(401),pg_temp.pr133_id(501),pg_temp.pr133_id(502));
select pg_temp.pr133_no_children('public.condominios',array[pg_temp.pr133_id(20),pg_temp.pr133_id(21)]);
delete from public.condominios where id in(pg_temp.pr133_id(20),pg_temp.pr133_id(21));
select pg_temp.pr133_no_children('public.profiles',array[pg_temp.pr133_id(1),pg_temp.pr133_id(2),pg_temp.pr133_id(3)]);
delete from public.profiles where id in(pg_temp.pr133_id(1),pg_temp.pr133_id(2),pg_temp.pr133_id(3));
-- Explicit Auth cleanup only after ALL inbound dependencies are absent; never cascade.
select pg_temp.pr133_no_children('auth.users',array[pg_temp.pr133_id(1),pg_temp.pr133_id(2),pg_temp.pr133_id(3)]);
delete from auth.users where id in(pg_temp.pr133_id(1),pg_temp.pr133_id(2),pg_temp.pr133_id(3))
 and raw_app_meta_data='{"fixture_package":"pr133-dev-20260920"}'::jsonb;
do $$ begin
 perform pg_temp.pr133_assert(not exists(select 1 from auth.users where id::text like '133c2026-0918-4000-8000-%')
  and not exists(select 1 from public.profiles where id::text like '133c2026-0918-4000-8000-%')
  and not exists(select 1 from public.unidades_condominio where id::text like '133c2026-0918-4000-8000-%')
  and not exists(select 1 from public.condominios where id::text like '133c2026-0918-4000-8000-%')
  and not exists(select 1 from public.client_identities where id in(select id from pr133_identities))
  and not exists(select 1 from public.client_reconciliation_candidates where id in(select id from pr133_candidates))
  and not exists(select 1 from public.respond_identity_links where respond_contact_id like 'pr133-dev-synthetic-20260920-%')
  and not exists(select 1 from public.client_identity_audit where actor_profile_id in(pg_temp.pr133_id(1),pg_temp.pr133_id(2),pg_temp.pr133_id(3)))
  and not exists(select 1 from public.respond_identity_audit where respond_contact_id like 'pr133-dev-synthetic-20260920-%'),
  'own synthetic fixtures and audit removed');
end $$;
select check_name,result from pr133_results;
commit;
select 'PR133 CLEANUP COMMITTED; own synthetic fixtures removed only' as result;
