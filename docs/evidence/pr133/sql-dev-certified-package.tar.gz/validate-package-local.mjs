// LOCAL ONLY validation of the existing eight SQL files. Never accepts a remote connection.
// Reuses the existing embedded PostgreSQL runtime; schema creation is loopback-only.
import assert from 'node:assert/strict';
import {readFile,writeFile,mkdtemp} from 'node:fs/promises';
import {join} from 'node:path';
import net from 'node:net';
import EmbeddedPostgres from '/private/tmp/condominium-identity-pg.2O15pu/node_modules/embedded-postgres/dist/index.js';
import pg from '/private/tmp/condominium-identity-pg.2O15pu/node_modules/pg/lib/index.js';
import {loadSql,executeBlock} from './run-dev-certification.mjs';
const packet='/private/tmp/pr133-dev-behavioral.vT0Zln';
const repo='/Users/carlos/Documents/ChatGPT/inmoadmin/condominium-owner-canonical-identity';
const catalog=JSON.parse(await readFile(join(packet,'dev-schema-diagnostic.json'),'utf8')).catalog;
const directory=await mkdtemp('/private/tmp/pr133-fixture-local-');
const socket=net.createServer();await new Promise((r,j)=>{socket.once('error',j);socket.listen(0,'127.0.0.1',r);});
const port=socket.address().port;await new Promise(r=>socket.close(r));
const cluster=new EmbeddedPostgres({databaseDir:join(directory,'data'),user:'postgres',password:'synthetic-local-only',port,persistent:true,
 postgresFlags:['-c','listen_addresses=127.0.0.1','-c',`unix_socket_directories=${directory}`],onLog(){},onError(){}});
const config={host:'127.0.0.1',port,user:'postgres',password:'synthetic-local-only',database:'postgres'};
const openClient=async()=>{assert.equal(config.host,'127.0.0.1');const c=new pg.Client(config);c.on('error',()=>{});await c.connect();
 c.certPid=(await c.query('select pg_backend_pid() pid')).rows[0].pid;return c;};
let db;const report={environment:'LOCAL embedded PostgreSQL — NOT Supabase DEV',tests:[],races:[],source_catalog:'DEV metadata only; no data copied'};
try{
 await cluster.initialise();await cluster.start();db=await openClient();
 await db.query(`create role anon;create role authenticated;create role service_role bypassrls;
 create schema auth;create schema extensions;create extension pgcrypto with schema extensions;
 create table public.roles(id text primary key);insert into public.roles values('admin'),('asesor'),('propietario');
 create table public.users(id uuid primary key);create table public.properties(id uuid primary key,owner_id uuid,status text);
 create table public.contracts(id uuid primary key,tenant_id uuid,tenant_phone text,property_id uuid references public.properties(id),status text,start_date date,end_date date);
 create table public.shadow_conversations(id uuid primary key,provider text,channel text);`);
 // Preserve actual required fields/defaults and Auth/profile FK in the LOCAL schema model.
 for(const [schema,table] of [['auth','users'],['public','profiles'],['public','condominios'],['public','unidades_condominio']]){
  const columns=catalog.all_columns.filter(x=>x.schema_name===schema&&x.table_name===table&&x.column_name!=='identity_owner_version');
  const definitions=columns.map(x=>`"${x.column_name}" ${x.data_type}${x.generated_kind?` generated always as (${x.default_expression}) stored`:x.default_expression?` default ${x.default_expression}`:''}${x.not_null?' not null':''}`);
  await db.query(`create table ${schema}.${table}(${definitions.join(',')})`);
  for(const c of catalog.all_constraints.filter(x=>x.schema_name===schema&&x.table_name===table&&!x.definition.includes('identity_owner_version')))
   await db.query(`alter table ${schema}.${table} add constraint "${c.constraint_name}" ${c.definition}`);
  await db.query(`alter table ${schema}.${table} enable row level security`);
 }
 const authTrigger=catalog.trigger_review.find(x=>x.table_name==='auth.users');
 assert.equal(authTrigger.function_body_md5,'25fe16f206acafd66f67b0967a19d706');
 await db.query(authTrigger.function_definition);await db.query(authTrigger.trigger_definition);
 await db.query(`grant usage on schema public,extensions to service_role,anon,authenticated;
 grant select on public.profiles,public.properties,public.contracts,public.unidades_condominio,public.condominios to service_role;`);
 // LOCAL pre-existing product schema only. These files are NEVER passed to the DEV launcher.
 for(const name of ['202608250004_fase_3a_respond_identity_bridge.sql','202608260002_fase_3a_canonical_client_model.sql',
  '202609090001_exact_phone_respond_identity_confirmation_7of7.sql','202609180001_condominium_owner_canonical_identity.sql'])
  await db.query(await readFile(join(repo,'supabase/migrations',name),'utf8'));
 await db.end();db=null;
 await executeBlock({openClient,sql:await loadSql(),report,emit:e=>console.log(JSON.stringify(e))});
 assert.equal(report.database_tests,'PASS');assert.equal(report.cleanup.result,'PASS');assert.deepEqual(report.cleanup.remaining,[]);
}catch(e){report.local_error={code:e.code||'local_assertion',message:e.message};console.error(JSON.stringify(report.local_error));process.exitCode=1;}
finally{if(db)await db.end();await cluster.stop();await writeFile(join(packet,'local-package-validation.json'),JSON.stringify(report,null,2)+'\n');}
