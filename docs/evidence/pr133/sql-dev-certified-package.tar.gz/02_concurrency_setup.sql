-- PR #133 HEAD e0cdda009dc1d9fbb92ccd67b1977bc18ab7d8bf
-- SOLO inmoadmin-dev / hjfwjnejbcpmknvfpdcq. Verificar proyecto en UI antes de ejecutar.
-- Prueba sintetica, NO migracion. No ejecutar en Produccion.
begin;
set local statement_timeout='40s';
set local lock_timeout='5s';
set local idle_in_transaction_session_timeout='45s';
create temporary table pr133_results(check_name text primary key, result text not null) on commit drop;
create or replace function pg_temp.pr133_id(n integer) returns uuid language sql immutable as $$
 select ('133c2026-0918-4000-8000-'||lpad(n::text,12,'0'))::uuid $$;
create or replace function pg_temp.pr133_phone(n integer) returns text language sql immutable as $$
 select '52000013'||lpad(n::text,4,'0') $$;
create or replace function pg_temp.pr133_contact(n integer) returns text language sql immutable as $$
 select 'pr133-dev-synthetic-20260920-'||n::text $$;
create or replace function pg_temp.pr133_assert(v boolean,label text) returns void language plpgsql as $$
begin
 if v is distinct from true then raise exception 'PR133 ASSERT FAILED: %',label; end if;
 insert into pg_temp.pr133_results values(label,'PASS');
end $$;
grant select,insert on pr133_results to anon,authenticated,service_role;
-- Actores Auth exclusivamente sinteticos en 01/02; sin login, roles nuevos ni permisos del negocio.
create or replace function pg_temp.pr133_unit(n integer, phone_n integer default null, condo_n integer default 20, active_value boolean default true)
returns void language plpgsql as $$
begin
 insert into public.unidades_condominio(id,condominio_id,numero,activo,propietario_telefono,propietario_nombre)
 values(pg_temp.pr133_id(n),pg_temp.pr133_id(condo_n),'PR133-'||n,active_value,pg_temp.pr133_phone(coalesce(phone_n,n)),'PR133 SYNTHETIC ONLY');
end $$;
create or replace function pg_temp.pr133_call(n integer, action_name text, candidate uuid default null,
 phone_n integer default null, actor_n integer default 1, contact_n integer default null,
 attach_identity boolean default false, observed_at timestamptz default clock_timestamp())
returns jsonb language sql as $$
 select public.review_condominium_owner_identity(action_name,pg_temp.pr133_id(n),
 pg_temp.pr133_contact(coalesce(contact_n,n)),pg_temp.pr133_id(actor_n),
 encode(extensions.digest(pg_temp.pr133_phone(coalesce(phone_n,n)),'sha256'),'hex'),
 observed_at,candidate,null,attach_identity) $$;

-- Precondiciones: fallo = detener, NO adaptar el esquema ni aplicar otras migraciones.
do $$
declare r record; bad text;
begin
 if current_user<>'postgres' then raise exception 'PR133 requires DEV SQL Editor postgres role'; end if;
 if to_regprocedure('public.review_condominium_owner_identity(text,uuid,text,uuid,text,timestamp with time zone,uuid,text,boolean)') is null then
  raise exception 'PR133 installed reviewer missing'; end if;
 if not exists(select 1 from pg_constraint where conrelid='public.profiles'::regclass and contype='f'
   and conname='profiles_id_fkey' and confrelid='auth.users'::regclass and convalidated
   and conkey=array[(select attnum from pg_attribute where attrelid='public.profiles'::regclass and attname='id')]
   and confkey=array[(select attnum from pg_attribute where attrelid='auth.users'::regclass and attname='id')]) then
  raise exception 'PR133 schema dependency: expected profiles_id_fkey to auth.users.id required'; end if;
 for r in select * from (values
  ('public.profiles',array['id','email','full_name','role_id','role','active','participa_kpis']::text[]),
  ('public.condominios',array['id','nombre','activo']::text[]),
  ('public.unidades_condominio',array['id','condominio_id','numero','activo','propietario_telefono','propietario_nombre']::text[]),
  ('auth.users',array['id','aud','role','email','encrypted_password','raw_app_meta_data','raw_user_meta_data','created_at','updated_at','banned_until','is_sso_user','is_anonymous']::text[])
 ) t(tbl,supplied) loop
  select string_agg(attname,',') into bad from pg_attribute a
   where a.attrelid=r.tbl::regclass and attnum>0 and not attisdropped
     and attnotnull and not atthasdef and attidentity='' and attgenerated=''
     and not attname=any(r.supplied);
  if bad is not null then raise exception 'PR133 schema dependency: %.% required',r.tbl,bad; end if;
 end loop;
 -- Pin the four reviewed triggers, including body, relation, event and enabled mode.
 if exists(select 1 from pg_trigger t join pg_proc p on p.oid=t.tgfoid where not t.tgisinternal and t.tgenabled<>'D'
   and t.tgrelid in ('auth.users'::regclass,'public.profiles'::regclass,'public.condominios'::regclass,'public.unidades_condominio'::regclass,
    'public.client_identities'::regclass,'public.client_identity_roles'::regclass,'public.client_source_links'::regclass,
    'public.client_reconciliation_candidates'::regclass,'public.client_reconciliation_candidate_sources'::regclass,
    'public.client_identity_audit'::regclass,'public.respond_identity_links'::regclass,'public.respond_identity_audit'::regclass)
   and not exists(select 1 from (values
    ('auth.users','on_auth_user_created','public.handle_new_user()',5,'25fe16f206acafd66f67b0967a19d706'),
    ('public.unidades_condominio','condominium_owner_identity_version','public.version_condominium_owner_identity()',19,'221b2328c392a5be762e3944b6e07828'),
    ('public.client_source_links','condominium_identity_source_guard','public.check_condominium_identity_source()',23,'6bd79a33aff7c8ab1dab288dcd38226a'),
    ('public.client_reconciliation_candidate_sources','condominium_candidate_source_guard','public.check_condominium_identity_source()',23,'6bd79a33aff7c8ab1dab288dcd38226a')
   ) expected(tbl,trg,fn,events,body_hash) where t.tgrelid=expected.tbl::regclass and t.tgname=expected.trg
     and t.tgfoid=expected.fn::regprocedure and t.tgtype=expected.events and t.tgenabled='O' and md5(p.prosrc)=expected.body_hash)) then
  raise exception 'PR133 unexpected active trigger: review metadata before inserting fixtures'; end if;
 if not exists(select 1 from pg_trigger where tgrelid='auth.users'::regclass and tgname='on_auth_user_created' and tgenabled='O') then
  raise exception 'PR133 schema dependency: reviewed Auth profile trigger required'; end if;
 if not exists(select 1 from public.roles where id='admin') or not exists(select 1 from public.roles where id='asesor') then
  raise exception 'PR133 schema dependency: existing admin/asesor roles required'; end if;
 -- Cleanup must be able to inspect dependencies without bypassing protections or cascading.
 for r in select distinct conrelid::regclass child_table from pg_constraint where contype='f'
  and confrelid in('auth.users'::regclass,'public.profiles'::regclass,'public.condominios'::regclass,
   'public.unidades_condominio'::regclass,'public.client_identities'::regclass,
   'public.client_reconciliation_candidates'::regclass,'public.respond_identity_links'::regclass) loop
  if not has_table_privilege(current_user,r.child_table,'SELECT') then
   raise exception 'PR133 cleanup SELECT permission missing: %',r.child_table using errcode='42501'; end if;
 end loop;
 -- Colisiones: no reutilizar ningun registro previo, aun si parece de una prueba.
 if exists(select 1 from auth.users where id::text like '133c2026-0918-4000-8000-%' or email like 'pr133.%@example.invalid')
 or exists(select 1 from public.profiles where id::text like '133c2026-0918-4000-8000-%' or email like 'pr133.%@example.invalid')
 or exists(select 1 from public.condominios where id::text like '133c2026-0918-4000-8000-%')
 or exists(select 1 from public.unidades_condominio where id::text like '133c2026-0918-4000-8000-%'
   or public.condominium_identity_phone_digest(propietario_telefono) in
      (select encode(extensions.digest(pg_temp.pr133_phone(n),'sha256'),'hex') from generate_series(0,999) n))
 or exists(select 1 from public.client_identities where id::text like '133c2026-0918-4000-8000-%'
   or phone_digest in (select encode(extensions.digest(pg_temp.pr133_phone(n),'sha256'),'hex') from generate_series(0,999) n))
 or exists(select 1 from public.respond_identity_links where respond_contact_id like 'pr133-dev-synthetic-20260920-%')
 or exists(select 1 from public.client_reconciliation_candidates where respond_contact_id like 'pr133-dev-synthetic-20260920-%') then
  raise exception 'PR133 fixture collision: do not overwrite or retry setup'; end if;
end $$;
-- Three inert Auth parents; no password, session, invitation, email/SMS or Auth API.
-- The reviewed AFTER INSERT trigger creates the profiles as staff/asesor.
insert into auth.users(id,aud,role,email,encrypted_password,raw_app_meta_data,raw_user_meta_data,
 created_at,updated_at,banned_until,is_sso_user,is_anonymous)
select pg_temp.pr133_id(n),'authenticated','authenticated',email,null,
 '{"fixture_package":"pr133-dev-20260920"}'::jsonb,'{}'::jsonb,now(),now(),'infinity'::timestamptz,false,false
from (values(1,'pr133.admin@example.invalid'),(2,'pr133.nonadmin@example.invalid'),(3,'pr133.inactive@example.invalid')) a(n,email);
select pg_temp.pr133_assert((select count(*)=3 from public.profiles where id in
 (pg_temp.pr133_id(1),pg_temp.pr133_id(2),pg_temp.pr133_id(3)) and role_id='asesor' and role='staff'),'Auth trigger created exactly three synthetic profiles');
update public.profiles p set full_name='PR133 SYNTHETIC ONLY',role_id=a.role_id,role=a.role,
 active=a.active,participa_kpis=false
from (values(1,'admin','admin',true),(2,'asesor','staff',true),(3,'admin','admin',false)) a(n,role_id,role,active)
where p.id=pg_temp.pr133_id(a.n);
select pg_temp.pr133_assert((select count(*)=3 from auth.users where id in
 (pg_temp.pr133_id(1),pg_temp.pr133_id(2),pg_temp.pr133_id(3))
 and encrypted_password is null and last_sign_in_at is null and invited_at is null
 and email_confirmed_at is null and phone_confirmed_at is null and confirmation_sent_at is null
 and recovery_sent_at is null and phone_change_sent_at is null and banned_until='infinity'::timestamptz),
 'synthetic Auth actors have no credentials or communications');
insert into public.condominios(id,nombre,activo) values
 (pg_temp.pr133_id(20),'PR133 SYNTHETIC CONDOMINIUM 20',true),(pg_temp.pr133_id(21),'PR133 SYNTHETIC CONDOMINIUM 21',false);

select pg_temp.pr133_unit(401);
select pg_temp.pr133_unit(501,500);
select pg_temp.pr133_unit(502,500);
-- Identidad/fuentes preexistentes SINTETICAS para competir por una sola identidad.
insert into public.client_identities(id,phone_digest) values(pg_temp.pr133_id(500),
 encode(extensions.digest(pg_temp.pr133_phone(500),'sha256'),'hex'));
insert into public.client_identity_roles(client_identity_id,role_kind) values(pg_temp.pr133_id(500),'owner');
insert into public.client_source_links(client_identity_id,source_type,source_id,condominium_id,role_kind,link_status,match_method,confirmed_by,confirmed_at)
select pg_temp.pr133_id(500),'condominium_unit_owner',pg_temp.pr133_id(n),pg_temp.pr133_id(20),
 'owner','confirmed','human_resolution',pg_temp.pr133_id(1),clock_timestamp() from unnest(array[501,502]) n;
set local role service_role;
do $$
declare n integer; r jsonb;
begin
 foreach n in array array[401,501,502] loop
  r:=pg_temp.pr133_call(n,'prepare',null,case when n=401 then 401 else 500 end);
  perform pg_temp.pr133_assert(r->>'status'='requires_review','concurrency candidate prepared '||n);
 end loop;
end $$;
reset role;
select check_name,result from pr133_results order by check_name;
commit;
select 'PR133 CONCURRENCY FIXTURES READY - cleanup 08 mandatory' as result;
