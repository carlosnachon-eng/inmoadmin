-- PR #133 HEAD e0cdda009dc1d9fbb92ccd67b1977bc18ab7d8bf
-- SOLO inmoadmin-dev / hjfwjnejbcpmknvfpdcq. Verificar proyecto en UI antes de ejecutar.
-- Prueba sintetica, NO migracion. No ejecutar en Produccion.
begin;
set local statement_timeout='40s';
set local lock_timeout='30s';
set local idle_in_transaction_session_timeout='45s';
create temporary table pr133_results(check_name text primary key, result text not null) on commit drop;
create or replace function pg_temp.pr133_id(n integer) returns uuid language sql immutable as $$
 select ('133c2026-0918-4000-8000-'||lpad(n::text,12,'0'))::uuid $$;
create or replace function pg_temp.pr133_phone(n integer) returns text language sql immutable as $$
 select '52000013'||lpad(n::text,4,'0') $$;
create or replace function pg_temp.pr133_contact(n integer) returns text language sql immutable as $$
 select 'pr133-dev-synthetic-20260920-'||n::text $$;
create or replace function pg_temp.pr133_assert(v boolean,label text) returns void language plpgsql as $$
begin
 if v is distinct from true then raise exception 'PR133 ASSERT FAILED: %',label; end if;
 insert into pg_temp.pr133_results values(label,'PASS');
end $$;
grant select,insert on pr133_results to anon,authenticated,service_role;
-- Actores Auth exclusivamente sinteticos en 01/02; sin login, roles nuevos ni permisos del negocio.
create or replace function pg_temp.pr133_unit(n integer, phone_n integer default null, condo_n integer default 20, active_value boolean default true)
returns void language plpgsql as $$
begin
 insert into public.unidades_condominio(id,condominio_id,numero,activo,propietario_telefono,propietario_nombre)
 values(pg_temp.pr133_id(n),pg_temp.pr133_id(condo_n),'PR133-'||n,active_value,pg_temp.pr133_phone(coalesce(phone_n,n)),'PR133 SYNTHETIC ONLY');
end $$;
create or replace function pg_temp.pr133_call(n integer, action_name text, candidate uuid default null,
 phone_n integer default null, actor_n integer default 1, contact_n integer default null,
 attach_identity boolean default false, observed_at timestamptz default clock_timestamp())
returns jsonb language sql as $$
 select public.review_condominium_owner_identity(action_name,pg_temp.pr133_id(n),
 pg_temp.pr133_contact(coalesce(contact_n,n)),pg_temp.pr133_id(actor_n),
 encode(extensions.digest(pg_temp.pr133_phone(coalesce(phone_n,n)),'sha256'),'hex'),
 observed_at,candidate,null,attach_identity) $$;

set local application_name='pr133-identity-B';
-- Estos dos archivos deben ejecutarse simultaneamente en conexiones distintas.
-- NO ejecutar si 02 no devolvio READY. No reintentar si falla.
create temporary table pr133_worker_result(payload jsonb,duration_ms numeric,pid integer) on commit drop;
grant insert,select on pr133_worker_result to service_role;
do $$ begin
 if not exists(select 1 from public.profiles where id=pg_temp.pr133_id(1) and email='pr133.admin@example.invalid'
  and full_name='PR133 SYNTHETIC ONLY' and role_id='admin' and active is true) then
  raise exception 'PR133 fixture ownership mismatch'; end if;
 if not exists(select 1 from public.unidades_condominio where id=pg_temp.pr133_id(502)
  and condominio_id=pg_temp.pr133_id(20) and propietario_nombre='PR133 SYNTHETIC ONLY'
  and propietario_telefono=pg_temp.pr133_phone(500)) then raise exception 'PR133 source fixture mismatch'; end if;
end $$;
set local role service_role;
do $$
declare r jsonb; cid uuid; t timestamptz:=clock_timestamp();
begin
 select id into strict cid from public.client_reconciliation_candidates
  where respond_contact_id=pg_temp.pr133_contact(502) and evidence_version='condominium_owner_review_v1';
 r:=pg_temp.pr133_call(502,'confirm',cid,500);
 perform pg_temp.pr133_assert(r->>'status'='rejected', 'pr133-identity-B expected rejected');
 perform pg_temp.pr133_assert(r->>'reason'='respond_identity_conflict','identity loser fail closed');
 insert into pr133_worker_result values(r,extract(epoch from clock_timestamp()-t)*1000,pg_backend_pid());
end $$;
reset role;

select 'identity' as race,'B' as worker,pid as backend_pid,payload->>'status' as status,
 payload->>'reason' as reason,duration_ms from pr133_worker_result;
select check_name,result from pr133_results order by check_name;
commit;
select 'pr133-identity-B: assertions passed and committed' as result;
