// PR133 DEV-only launcher. Executes the existing eight SQL files, never a bootstrap.
// No credentials in argv, environment files, reports, repository, or console.
import { readFile, writeFile, open, stat } from 'node:fs/promises';
import { createHash, X509Certificate } from 'node:crypto';
import { spawn } from 'node:child_process';
import { fileURLToPath, pathToFileURL } from 'node:url';
import { dirname, join } from 'node:path';
import { setTimeout as delay } from 'node:timers/promises';
import { createInterface } from 'node:readline';

export const PROJECT = 'hjfwjnejbcpmknvfpdcq';
export const HEAD = 'e0cdda009dc1d9fbb92ccd67b1977bc18ab7d8bf';
const VERIFIED_HOST = 'aws-0-us-east-2.pooler.supabase.com';
const OFFICIAL_CA_SETTINGS = `https://supabase.com/dashboard/project/${PROJECT}/database/settings`;
const RECEIVED_CA_PATH = '/Users/carlos/Downloads/prod-ca-2021.crt';
const RECEIVED_CA_FINGERPRINT = '80:70:25:AD:50:D4:ED:21:9D:2C:9C:7D:29:9C:00:4F:82:4E:B0:0C:F7:F6:5A:FE:F6:07:D0:7B:72:E6:CA:FA';
const DIRECTORY = dirname(fileURLToPath(import.meta.url));
const PG_MODULE = '/private/tmp/condominium-identity-pg.2O15pu/node_modules/pg/lib/index.js';
export const FILES = Object.freeze({
  '01_behavioral_rollback.sql':'3511096cda2e2ef91e5d23021150ae1d9f47844eb914cf0979555aa4adb52b20',
  '02_concurrency_setup.sql':'ae64472a837b2e18b269e0b7686b95c27401fcf68c711fb544066cf335b1d3f2',
  '03_same_contact_A.sql':'6874f889acca1c3179b4fa4565a81f9eacf7fbc128bf1674ddc0a31c9de21b7c',
  '04_same_contact_B.sql':'806fa82db2adaac89a9e7b9cd22e272119787a9424c2754e89f5348b118de0ad',
  '05_same_identity_A.sql':'88583ffba5c9e41b117fb1d56d77b53dd9889c711d943642c0099f289da63695',
  '06_same_identity_B.sql':'e94fcb19ee38554fbc819ce647deb2a3cf641be9ceae62a1dc145602538a3cfc',
  '07_concurrency_verify.sql':'aaa46897299716ec810414d18c7ca638111f0fee9a174fdc8a5a0c8ef3d74d32',
  '08_cleanup.sql':'7c6bf2d4fdba35ca79fbc01e08b70de4aa333fe077d3179774fd3e4f588b72aa',
});
const failure = code => Object.assign(new Error(code), { safeCode:code });
export function parseCredential(raw) {
  let u;
  try { u = new URL(raw.trim()); } catch { throw failure('invalid_connection_credential'); }
  const user = decodeURIComponent(u.username);
  const password = decodeURIComponent(u.password);
  const direct = u.hostname === `db.${PROJECT}.supabase.co` && user === 'postgres';
  const session = /^aws-[0-9]+-[a-z0-9-]+\.pooler\.supabase\.com$/.test(u.hostname) && user === `postgres.${PROJECT}`;
  if (!['postgres:','postgresql:'].includes(u.protocol) || (!direct && !session) ||
      u.port !== '5432' || u.pathname !== '/postgres' || u.hash || !password ||
      /\[YOUR-PASSWORD\]|\[PASSWORD\]/i.test(password) || /[\r\n\0]/.test(password)) throw failure('destination_or_credential_rejected');
  for (const [k,v] of u.searchParams) if (k !== 'sslmode' || !['require','verify-full'].includes(v)) throw failure('connection_options_rejected');
  return { host:u.hostname, port:5432, user, password, database:'postgres', mode:direct?'direct':'session_pooler' };
}
export function certificateMetadata(cert) {
  return {issuer:cert.issuer,valid_from:cert.validFrom,valid_to:cert.validTo,sha256:cert.fingerprint256};
}
export function validateOfficialRoot(bytes) {
  if(!bytes?.length || bytes.length>65536)throw failure('invalid_root_certificate_size');
  const text=bytes.toString('utf8');
  if(/PRIVATE KEY/.test(text))throw failure('private_key_not_allowed');
  if(text.includes('-----BEGIN') && !/^\s*-----BEGIN CERTIFICATE-----[A-Za-z0-9+/=\r\n]+-----END CERTIFICATE-----\s*$/.test(text))throw failure('single_root_certificate_required');
  let cert;try{cert=new X509Certificate(bytes);}catch{throw failure('invalid_root_certificate');}
  if(cert.ca!==true || cert.subject!==cert.issuer || !cert.verify(cert.publicKey))throw failure('self_signed_ca_root_required');
  if(!(Date.now()>=Date.parse(cert.validFrom) && Date.now()<Date.parse(cert.validTo)))throw failure('root_certificate_not_current');
  return {pem:cert.toString(),metadata:certificateMetadata(cert)};
}
export function clientConfig(credential, officialRoot) {
  if (process.env.NODE_TLS_REJECT_UNAUTHORIZED === '0') throw failure('tls_verification_disabled_in_environment');
  if(!officialRoot?.pem)throw failure('official_root_certificate_required');
  return { host:credential.host, port:5432, user:credential.user, password:credential.password, database:'postgres',
    ssl:{ ca:officialRoot.pem, rejectUnauthorized:true, servername:credential.host, minVersion:'TLSv1.2' },
    sslnegotiation:'postgres',
    connectionTimeoutMillis:12000, query_timeout:45000,
    options:'-c statement_timeout=40000 -c lock_timeout=5000 -c idle_in_transaction_session_timeout=45000',
    application_name:'pr133-dev-certification', keepAlive:true };
}
export function assertEffectiveTls(client,config) {
  // Never give pg a connectionString: its SSL query parameters can replace the entire ssl object.
  const cp=client.connectionParameters;
  if(config.connectionString!==undefined || cp.host!==config.host || cp.port!==5432 || cp.sslnegotiation!=='postgres')throw failure('effective_connection_config_mismatch');
  for(const ssl of [cp.ssl,client.connection.ssl]) {
    if(!ssl || ssl.ca!==config.ssl.ca || ssl.rejectUnauthorized!==true || ssl.servername!==config.host ||
      ssl.minVersion!=='TLSv1.2' || Object.hasOwn(ssl,'checkServerIdentity') || Object.keys(ssl).some(k=>!['ca','rejectUnauthorized','servername','minVersion'].includes(k)))throw failure('effective_tls_config_mismatch');
  }
}
function peerCertificateMetadata(stream) {
  // Observation only: peer certificates never become trust anchors. Preserve normal TLS/hostname verification.
  try {
    let cert=stream?.getPeerCertificate?.(true);const seen=new Set(),out=[];
    while(cert?.raw && out.length<8) {
      const parsed=new X509Certificate(cert.raw);if(seen.has(parsed.fingerprint256))break;
      seen.add(parsed.fingerprint256);out.push(certificateMetadata(parsed));cert=cert.issuerCertificate;
    }
    return out;
  }catch{return [];}
}
async function loadReceivedOfficialRoot() {
  const file=await stat(RECEIVED_CA_PATH);if(!file.isFile()||file.size>65536)throw failure('invalid_root_certificate_file');
  const root=validateOfficialRoot(await readFile(RECEIVED_CA_PATH));
  if(root.metadata.sha256!==RECEIVED_CA_FINGERPRINT)throw failure('previously_received_ca_fingerprint_changed');
  return root;
}
export function safeError(error) {
  const out={ code:error?.safeCode || (/^[A-Z0-9_]{2,50}$/.test(error?.code||'')?error.code:'unclassified_error') };
  if(['session_pooler_template','postgres_password'].includes(error?.captureField))out.capture_field=error.captureField;
  if(Number.isInteger(error?.dialogErrorNumber))out.dialog_error_number=error.dialogErrorNumber;
  // Do not print driver message/detail/where/stack; they can contain SQL or connection credentials.
  const text=String(error?.message||'');
  if (text.startsWith('PR133 ASSERT FAILED: ')) out.reason='assertion_failed';
  else if (text.startsWith('PR133 schema dependency:')) {
    out.reason='schema_dependency';
    if(text==='PR133 schema dependency: profiles.id has FK; no Auth users will be created')Object.assign(out,{object:'public.profiles.id',condition:'no_profile_id_foreign_key'});
    else if(text==='PR133 schema dependency: existing admin/coord_operaciones roles required')Object.assign(out,{object:'public.roles',condition:'admin_and_coord_operaciones_exist'});
    else {const m=/^PR133 schema dependency: (profiles|condominios|unidades_condominio)\.([a-z_][a-z0-9_]*(?:,[a-z_][a-z0-9_]*)*) required$/.exec(text);
      if(m)Object.assign(out,{object:'public.'+m[1],columns:m[2].split(','),condition:'required_columns_missing_from_fixture'});}
  }
  else if (text.startsWith('PR133 fixture collision:')) out.reason='fixture_collision';
  else if (text.startsWith('PR133 unexpected active trigger:')) out.reason='unexpected_active_trigger';
  else if (text.startsWith('PR133 cleanup')) {
    out.reason='cleanup_guard_rejected';
    const m=/^PR133 cleanup SELECT permission missing: ([a-z_][a-z0-9_.]*)$/.exec(text);
    if(m)Object.assign(out,{object:m[1],permission:'SELECT'});
  }
  else if (text.startsWith('PR133')) out.reason='fixture_or_schema_guard';
  return out;
}
export async function loadSql() {
  const sql={};
  for(const [name,expected] of Object.entries(FILES)) {
    const value=await readFile(join(DIRECTORY,name),'utf8');
    if(createHash('sha256').update(value).digest('hex')!==expected) throw failure('certified_sql_hash_mismatch');
    sql[name]=value;
  }
  return sql;
}
export function splitSetup(text) {
  const boundary='\ncommit;\n';
  if(text.split(boundary).length!==2) throw failure('setup_transaction_boundary_changed');
  const [before,after]=text.split(boundary);
  return [before+'\n','commit;\n'+after];
}
export function parseSessionTemplate(raw) {
  let u;try{u=new URL(raw.trim());}catch{throw failure('invalid_session_pooler_template');}
  if(decodeURIComponent(u.password)!=='[YOUR-PASSWORD]')throw failure('template_requires_password_placeholder');
  u.password='template-validation-only';
  const route=parseCredential(u.href);
  if(route.host!==VERIFIED_HOST || route.mode!=='session_pooler')throw failure('previously_verified_server_required');
  delete route.password;return route;
}
export function composeCredential(route,password) {
  if(typeof password!=='string'||!password.length||/[\r\n\0]/.test(password)||password==='[YOUR-PASSWORD]')throw failure('empty_or_invalid_password_input');
  // Pass the password as a separate pg property. Never interpolate it into a URI or trim it.
  return {...route,password};
}
export function decodeCaptureOutput(output,exitCode,stderrNumber) {
  // osascript adds one transport newline; preserve all whitespace actually entered by the user.
  const value=output.replace(/\r?\n$/,'');
  if(exitCode===0 && value.startsWith('VALUE:'))return value.slice(6);
  if(value==='STATUS:CANCELLED'||stderrNumber===-128)throw Object.assign(failure('secure_capture_cancelled'),{dialogErrorNumber:-128});
  if(value==='STATUS:TIMEOUT')throw failure('secure_capture_dialog_timeout');
  const match=/^ERROR:(-?\d+)$/.exec(value);
  const number=match?Number(match[1]):stderrNumber;
  if(Number.isInteger(number))throw Object.assign(failure('secure_capture_dialog_error'),{dialogErrorNumber:number});
  throw failure('secure_capture_failed_unknown_reason');
}
async function captureField(field) {
  const hidden=field==='postgres_password';
  const prompt=hidden?`Paso 2/2: contraseña PostgreSQL de inmoadmin-dev (${PROJECT}). Sólo memoria. No API key ni service-role.`:
    `Paso 1/2: pega la cadena oficial de Session pooler DEV (${PROJECT}), puerto 5432, manteniendo [YOUR-PASSWORD]. No incluyas la contraseña; se pedirá oculta después.`;
  console.log(JSON.stringify({stage:'secure_capture_requested',field,hidden}));
  const script=`try
set dialogResult to display dialog "${prompt}" default answer "" ${hidden?'with hidden answer ':''}buttons {"Cancelar", "Continuar DEV"} default button "Continuar DEV" cancel button "Cancelar" with title "PR133 — PostgreSQL DEV ${hidden?'2/2':'1/2'}" giving up after 300
if gave up of dialogResult then return "STATUS:TIMEOUT"
return "VALUE:" & (text returned of dialogResult)
on error errorMessage number errorNumber
if errorNumber is -128 then return "STATUS:CANCELLED"
return "ERROR:" & (errorNumber as text)
end try`;
  try{return await new Promise((resolve,reject)=>{
    const child=spawn('/usr/bin/osascript',['-e',script],{stdio:['ignore','pipe','pipe']});
    const chunks=[],errors=[];let size=0,errorSize=0,settled=false;
    const stop=e=>{if(settled)return;settled=true;clearTimeout(timer);child.kill();reject(e);};
    const timer=setTimeout(()=>stop(failure('secure_capture_process_timeout')),305000);
    child.stdout.on('data',b=>{size+=b.length;if(size>8192){b.fill(0);stop(failure('capture_input_too_long'));}else chunks.push(b);});
    child.stderr.on('data',b=>{errorSize+=b.length;if(errorSize<=16384)errors.push(b);else b.fill(0);});
    child.on('error',e=>{const err=failure('secure_capture_process_could_not_start');if(['ENOENT','EACCES'].includes(e.code))err.safeCode+='_'+e.code;stop(err);});
    child.on('close',code=>{
      clearTimeout(timer);const data=Buffer.concat(chunks),err=Buffer.concat(errors);
      try{if(!settled){settled=true;const n=/\((-?\d+)\)\s*$/.exec(err.toString('utf8'));
        resolve(decodeCaptureOutput(data.toString('utf8'),code,n?Number(n[1]):undefined));}}
      catch(e){reject(e);}finally{data.fill(0);err.fill(0);chunks.forEach(b=>b.fill(0));errors.forEach(b=>b.fill(0));}
    });
  });}catch(e){e.captureField=field;throw e;}
}
async function captureCredential() {
  const route=parseSessionTemplate(await captureField('session_pooler_template'));
  console.log(JSON.stringify({stage:'session_pooler_template_validated',project:PROJECT,host:route.host,port:5432}));
  return composeCredential(route,await captureField('postgres_password'));
}
const INVENTORY=`with candidates as (
 select id,client_identity_id from public.client_reconciliation_candidates where respond_contact_id like 'pr133-dev-synthetic-20260920-%'
), identities as (select '133c2026-0918-4000-8000-000000000500'::uuid id union select client_identity_id from candidates where client_identity_id is not null),
 links as (select id from public.respond_identity_links where respond_contact_id like 'pr133-dev-synthetic-20260920-%' or client_identity_id in(select id from identities))
select 'profiles' kind,id::text id from public.profiles where id::text like '133c2026-0918-4000-8000-%'
union all select 'auth.users',id::text from auth.users where id::text like '133c2026-0918-4000-8000-%'
union all select 'condominios',id::text from public.condominios where id::text like '133c2026-0918-4000-8000-%'
union all select 'unidades_condominio',id::text from public.unidades_condominio where id::text like '133c2026-0918-4000-8000-%'
union all select 'client_reconciliation_candidates',id::text from candidates
union all select 'client_reconciliation_candidate_sources',candidate_id::text||':'||source_id::text from public.client_reconciliation_candidate_sources where candidate_id in(select id from candidates) or source_id::text like '133c2026-0918-4000-8000-%'
union all select 'client_identities',id::text from public.client_identities where id in(select id from identities)
union all select 'client_identity_roles',client_identity_id::text||':'||role_kind from public.client_identity_roles where client_identity_id in(select id from identities)
union all select 'client_source_links',id::text from public.client_source_links where client_identity_id in(select id from identities) or source_id::text like '133c2026-0918-4000-8000-%'
union all select 'respond_identity_links',id::text from links
union all select 'client_identity_audit',id::text from public.client_identity_audit where candidate_id in(select id from candidates) or client_identity_id in(select id from identities) or actor_profile_id::text like '133c2026-0918-4000-8000-%' or context_ids->>'unitId' like '133c2026-0918-4000-8000-%'
union all select 'respond_identity_audit',id::text from public.respond_identity_audit where link_id in(select id from links) or respond_contact_id like 'pr133-dev-synthetic-20260920-%' or actor_profile_id::text like '133c2026-0918-4000-8000-%'
order by kind,id`;
export function safeRows(result) {
  const rows=(Array.isArray(result)?result:[result]).flatMap(r=>r?.rows||[]);
  return rows.flatMap(r=>{
    if(typeof r.check_name==='string' && r.result==='PASS') return [{check:r.check_name.slice(0,160),result:'PASS'}];
    if(['contact','identity'].includes(r.race) && ['A','B'].includes(r.worker)) return [{race:r.race,worker:r.worker,
      backend_pid:Number(r.backend_pid),status:['confirmed','already_confirmed','rejected'].includes(r.status)?r.status:'invalid',
      reason:r.reason==='respond_identity_conflict'?r.reason:null,duration_ms:Number(r.duration_ms)}];
    return [];
  });
}
async function boundedQuery(client,text,values,ms=45000) {
  let timer;
  try { return await Promise.race([client.query(text,values),new Promise((_,reject)=>{timer=setTimeout(()=>{
    client.connection?.stream?.destroy();reject(failure('query_deadline_exceeded'));},ms);})]); }
  finally {clearTimeout(timer);}
}
async function close(client) {
  if(!client)return;
  try { await boundedQuery(client,'rollback',undefined,2000); } catch {client.connection?.stream?.destroy();}
  try { await Promise.race([client.end(),delay(2000).then(()=>client.connection?.stream?.destroy())]); } catch {}
}
async function diagnoseSchema(client,report,emit) {
  const fixtureTables=['profiles','condominios','unidades_condominio'];
  const supplied={profiles:['id','email','full_name','role_id','active'],condominios:['id','nombre','activo'],
    unidades_condominio:['id','condominio_id','numero','activo','propietario_telefono','propietario_nombre']};
  const tables=[...fixtureTables,'client_identities','client_identity_roles','client_source_links','client_reconciliation_candidates',
    'client_reconciliation_candidate_sources','client_identity_audit','respond_identity_links','respond_identity_audit'];
  const migration=await readFile('/Users/carlos/Documents/ChatGPT/inmoadmin/condominium-owner-canonical-identity/supabase/migrations/202609180001_condominium_owner_canonical_identity.sql','utf8');
  const expected=[...migration.matchAll(/create function public\.(\w+)\([\s\S]*?\bas \$\$([\s\S]*?)\$\$;/g)]
    .map(m=>({name:m[1],body_md5:createHash('md5').update(m[2]).digest('hex')}));
  if(expected.length!==6)throw failure('local_function_diagnostic_manifest_mismatch');
  const diag={read_only:true,fixture_writes:0,checks:[],catalog:{}};report.schema_diagnostic=diag;
  const check=(object,condition,pass,observed)=>{const row={object,condition,result:pass?'PASS':'FAIL',observed};diag.checks.push(row);emit({stage:'schema_catalog_check',...row});};
  const q=async(text,values)=>(await boundedQuery(client,text,values,12000)).rows;
  await boundedQuery(client,'begin read only',undefined,3000);
  try {
    diag.catalog.functions=await q(`select p.proname name,p.oid::regprocedure::text signature,md5(p.prosrc) body_md5,p.prosecdef security_definer,
      p.provolatile volatility,p.proconfig config from pg_proc p join pg_namespace n on n.oid=p.pronamespace
      where n.nspname='public' and p.proname=any($1) order by p.proname`,[expected.map(x=>x.name)]);
    for(const e of expected){const actual=diag.catalog.functions.filter(x=>x.name===e.name);
      check('public.'+e.name,'single installed function body identical to certified migration',actual.length===1&&actual[0].body_md5===e.body_md5,actual);}
    const reviewer=await q(`select to_regprocedure('public.review_condominium_owner_identity(text,uuid,text,uuid,text,timestamp with time zone,uuid,text,boolean)') is not null present`);
    check('public.review_condominium_owner_identity','exact certified signature exists',reviewer[0].present,reviewer[0]);
    diag.catalog.foreign_keys=await q(`select c.conname constraint_name,n.nspname schema_name,t.relname table_name,
      (select array_agg(a.attname::text order by k.ord) from unnest(c.conkey) with ordinality k(num,ord) join pg_attribute a on a.attrelid=c.conrelid and a.attnum=k.num) columns,
      rn.nspname referenced_schema,rt.relname referenced_table,
      (select array_agg(a.attname::text order by k.ord) from unnest(c.confkey) with ordinality k(num,ord) join pg_attribute a on a.attrelid=c.confrelid and a.attnum=k.num) referenced_columns,
      c.condeferrable deferrable,c.convalidated validated,c.confdeltype delete_action
      from pg_constraint c join pg_class t on t.oid=c.conrelid join pg_namespace n on n.oid=t.relnamespace
      join pg_class rt on rt.oid=c.confrelid join pg_namespace rn on rn.oid=rt.relnamespace
      where c.contype='f' and n.nspname='public' and t.relname=any($1) order by t.relname,c.conname`,[fixtureTables]);
    const profileFks=diag.catalog.foreign_keys.filter(x=>x.table_name==='profiles'&&x.columns.includes('id'));
    check('public.profiles.id','validated FK to auth.users.id retained; Auth fixtures required',profileFks.length===1&&profileFks[0].referenced_schema==='auth'&&profileFks[0].referenced_table==='users'&&profileFks[0].validated,profileFks);
    diag.catalog.columns=await q(`select t.relname table_name,a.attname column_name,format_type(a.atttypid,a.atttypmod) data_type,
      a.attnotnull not_null,a.atthasdef has_default,a.attidentity identity_kind,a.attgenerated generated_kind
      from pg_attribute a join pg_class t on t.oid=a.attrelid join pg_namespace n on n.oid=t.relnamespace
      where n.nspname='public' and t.relname=any($1) and a.attnum>0 and not a.attisdropped order by t.relname,a.attnum`,[fixtureTables]);
    for(const table of fixtureTables){const cols=diag.catalog.columns.filter(x=>x.table_name===table);
      check('public.'+table,'fixture columns exist',supplied[table].every(name=>cols.some(x=>x.column_name===name)),{missing:supplied[table].filter(name=>!cols.some(x=>x.column_name===name))});
      const missing=cols.filter(x=>x.not_null&&!x.has_default&&!x.identity_kind&&!x.generated_kind&&!supplied[table].includes(x.column_name));
      check('public.'+table,'all required columns supplied by fixture',!missing.length,missing);}
    // Application role identifiers only, never users or business records.
    diag.catalog.application_roles=await q(`select id from public.roles where id in ('admin','asesor','staff','propietario','inquilino','condomino','coord_operaciones') order by id`);
    check('public.roles','admin and existing nonadmin application role',diag.catalog.application_roles.some(x=>x.id==='admin')&&diag.catalog.application_roles.some(x=>x.id!=='admin'),diag.catalog.application_roles);
    diag.catalog.triggers=await q(`select t.relname table_name,g.tgname trigger_name,g.tgfoid::regprocedure::text function_signature,
      g.tgenabled enabled,md5(p.prosrc) function_body_md5,pg_get_triggerdef(g.oid) definition
      from pg_trigger g join pg_class t on t.oid=g.tgrelid join pg_namespace n on n.oid=t.relnamespace join pg_proc p on p.oid=g.tgfoid
      where n.nspname='public' and t.relname=any($1) and not g.tgisinternal and g.tgenabled<>'D' order by t.relname,g.tgname`,[tables]);
    const allowed=['condominium_owner_identity_version','condominium_identity_source_guard','condominium_candidate_source_guard'];
    check('fixture tables','only triggers currently allowed by fixture package',diag.catalog.triggers.every(x=>allowed.includes(x.trigger_name)),diag.catalog.triggers);
    diag.catalog.constraints=await q(`select t.relname table_name,c.conname constraint_name,c.contype type,pg_get_constraintdef(c.oid) definition
      from pg_constraint c join pg_class t on t.oid=c.conrelid join pg_namespace n on n.oid=t.relnamespace
      where n.nspname='public' and t.relname=any($1) and c.contype in ('c','u','p') order by t.relname,c.conname`,[fixtureTables]);
    // Metadata-only dependency review for ALL tables touched by fixtures and Auth parents.
    const qualified=[...tables.map(t=>'public.'+t),'auth.users'];
    diag.catalog.all_columns=await q(`select n.nspname schema_name,t.relname table_name,a.attname column_name,
      format_type(a.atttypid,a.atttypmod) data_type,a.attnotnull not_null,a.atthasdef has_default,
      a.attidentity identity_kind,a.attgenerated generated_kind,pg_get_expr(d.adbin,d.adrelid) default_expression
      from pg_attribute a join pg_class t on t.oid=a.attrelid join pg_namespace n on n.oid=t.relnamespace
      left join pg_attrdef d on d.adrelid=a.attrelid and d.adnum=a.attnum
      where a.attrelid=any($1::regclass[]) and a.attnum>0 and not a.attisdropped order by n.nspname,t.relname,a.attnum`,[qualified]);
    diag.catalog.all_constraints=await q(`select n.nspname schema_name,t.relname table_name,c.conname constraint_name,c.contype type,
      c.convalidated validated,pg_get_constraintdef(c.oid) definition from pg_constraint c join pg_class t on t.oid=c.conrelid
      join pg_namespace n on n.oid=t.relnamespace where c.conrelid=any($1::regclass[]) order by n.nspname,t.relname,c.conname`,[qualified]);
    diag.catalog.inbound_foreign_keys=await q(`select c.conrelid::regclass::text child_table,c.confrelid::regclass::text parent_table,
      c.conname constraint_name,pg_get_constraintdef(c.oid) definition from pg_constraint c
      where c.contype='f' and c.confrelid=any($1::regclass[]) order by child_table,c.conname`,[qualified]);
    diag.catalog.trigger_review=await q(`select g.tgrelid::regclass::text table_name,g.tgname trigger_name,g.tgenabled enabled,
      pg_get_triggerdef(g.oid) trigger_definition,g.tgfoid::regprocedure::text function_signature,md5(p.prosrc) function_body_md5,
      pg_get_functiondef(g.tgfoid) function_definition from pg_trigger g join pg_proc p on p.oid=g.tgfoid
      where g.tgrelid=any($1::regclass[]) and not g.tgisinternal and g.tgenabled<>'D' order by table_name,g.tgname`,[qualified]);
    diag.catalog.fixture_permissions=await q(`select x.table_name,has_table_privilege(current_user,x.table_name,'SELECT') can_select,
      has_table_privilege(current_user,x.table_name,'INSERT') can_insert,has_table_privilege(current_user,x.table_name,'UPDATE') can_update,
      has_table_privilege(current_user,x.table_name,'DELETE') can_delete from unnest($1::text[]) x(table_name)`,[qualified]);
    emit({stage:'auth_and_fixture_metadata_collected',tables:qualified,trigger_count:diag.catalog.trigger_review.length,
      role_ids:diag.catalog.application_roles.map(x=>x.id),fixture_writes:0,review_required_before_continuation:true});
  } finally {await boundedQuery(client,'rollback',undefined,3000);}
  await writeFile(join(DIRECTORY,'dev-schema-diagnostic.json'),JSON.stringify(diag,null,2)+'\n',{mode:0o600});
  return diag;
}
async function waitForDiagnosticDecision() {
  console.log(JSON.stringify({stage:'schema_diagnostic_complete_read_only',next:'STOP or CONTINUE_AFTER_PACKAGE_FIX; no fixture writes before explicit continuation',timeout_seconds:900}));
  return new Promise((resolve,reject)=>{
    const input=createInterface({input:process.stdin,terminal:false});
    const done=(value)=>{clearTimeout(timer);input.close();resolve(value);};
    const timer=setTimeout(()=>done('STOP'),900000);
    input.once('line',line=>done(line.trim()));input.once('error',()=>{clearTimeout(timer);input.close();reject(failure('diagnostic_control_unavailable'));});
  });
}
export async function executeBlock({openClient,sql,report,emit}) {
  report.actor_roles={active_admin:'admin',active_nonadmin:'asesor',inactive_admin:'admin',coord_operaciones_tested:false};
  const clients=[];let coordinator,a,b,observer,manifest=null,commitAttempted=false,baselinePassed=false;
  let expired=false;
  const abort=()=>{expired=true;for(const c of [coordinator,a,b])c?.connection?.stream?.destroy();};
  const blockTimer=setTimeout(abort,180000);
  process.once('SIGINT',abort);process.once('SIGTERM',abort);
  const acquire=async()=>{const c=await openClient();clients.push(c);return c;};
  const inventory=async c=>(await boundedQuery(c,INVENTORY,undefined,10000)).rows;
  const run=async(c,name)=>{const start=Date.now();try{
    if(expired && name!=='08_cleanup.sql')throw failure('block_deadline_or_interrupt');
    const result=await boundedQuery(c,sql[name]);const entry={file:name,result:'PASS',duration_ms:Date.now()-start,evidence:safeRows(result)};
    report.tests.push(entry);emit(entry);return entry;
  }catch(e){const entry={file:name,result:'FAIL',duration_ms:Date.now()-start,error:safeError(e)};report.tests.push(entry);emit(entry);throw e;}};
  const race=async(kind,fa,fb)=>{
    const ap=run(a,fa);ap.catch(()=>{});
    try{
      const deadline=Date.now()+10000;let ready=false;
      while(Date.now()<deadline){
        if(expired)throw failure('block_deadline_or_interrupt');
        const r=await boundedQuery(observer,`select exists(select 1 from pg_stat_activity s join pg_locks l on l.pid=s.pid
          where s.pid=$1 and s.application_name=$2 and l.locktype='relation' and l.relation='public.client_identities'::regclass
          and l.mode='ShareRowExclusiveLock' and l.granted) ready`,[a.certPid,`pr133-${kind}-A`],2500);
        if(r.rows[0]?.ready){ready=true;break;} await delay(100);
      }
      if(!ready)throw failure('worker_a_did_not_reach_held_lock');
      const bp=run(b,fb);const settled=await Promise.allSettled([ap,bp]);
      const failed=settled.find(r=>r.status==='rejected');if(failed)throw failed.reason;
      const ae=settled[0].value.evidence,be=settled[1].value.evidence;
      const ar=ae.find(x=>x.worker==='A'),br=be.find(x=>x.worker==='B');
      if(!ar||!br||ar.backend_pid===br.backend_pid||!ae.some(x=>x.check?.includes('independent B connection observed blocked by A')))throw failure('missing_concurrency_evidence');
      report.races.push({kind,independent_connections:true,blocking_observed:true,A:ar.status,B:br.status,reason:br.reason});
    }catch(e){a.connection?.stream?.destroy();b.connection?.stream?.destroy();await ap.catch(()=>{});throw e;}
  };
  try{
    // All four authenticated, TLS-verified sessions must exist before any fixture write.
    coordinator=await acquire();a=await acquire();b=await acquire();observer=await acquire();
    if(new Set(clients.map(c=>c.certPid)).size!==4)throw failure('sessions_not_independent');
    const initial=await inventory(coordinator);
    if(initial.length){report.preexisting_fixture_refs=initial;throw failure('preexisting_fixture_collision_no_cleanup_allowed');}
    baselinePassed=true;
    await run(coordinator,'01_behavioral_rollback.sql');
    if((await inventory(coordinator)).length)throw failure('sequential_rollback_residuals');
    const [setupBody,setupCommit]=splitSetup(sql['02_concurrency_setup.sql']);
    if(expired)throw failure('block_deadline_or_interrupt');
    // Capture ownership BEFORE COMMIT. If COMMIT acknowledgement is lost, cleanup remains precisely scoped.
    const prepared=await boundedQuery(coordinator,setupBody);
    manifest=await inventory(coordinator);
    const counts=Object.fromEntries([...new Set(manifest.map(x=>x.kind))].map(k=>[k,manifest.filter(x=>x.kind===k).length]));
    if(counts['auth.users']!==3||counts.profiles!==3||counts.condominios!==2||counts.unidades_condominio!==3||counts.client_reconciliation_candidates!==3||counts.client_identities!==1)throw failure('unexpected_fixture_manifest');
    report.created_fixture_manifest=manifest;commitAttempted=true;
    await boundedQuery(coordinator,setupCommit);
    const setupEntry={file:'02_concurrency_setup.sql',result:'PASS',evidence:safeRows(prepared)};report.tests.push(setupEntry);emit(setupEntry);
    await race('contact','03_same_contact_A.sql','04_same_contact_B.sql');
    await race('identity','05_same_identity_A.sql','06_same_identity_B.sql');
    await run(coordinator,'07_concurrency_verify.sql');
    report.database_tests='PASS';
  }catch(e){report.database_tests='FAIL_OR_BLOCKED';report.error=safeError(e);emit({stage:'database_tests',error:report.error});}
  finally{
    // Close workers and release/rollback coordinator first; cleanup uses the separate verified observer.
    await Promise.all([close(a),close(b),close(coordinator)]);
    if(commitAttempted && manifest && observer){
      try{
        // Do not delete candidates introduced by another operation in our reserved namespace.
        const current=await inventory(observer);
        const owned=new Set(manifest.filter(x=>x.kind==='client_reconciliation_candidates').map(x=>x.id));
        if(current.some(x=>x.kind==='client_reconciliation_candidates'&&!owned.has(x.id)))throw failure('cleanup_foreign_candidate_detected');
        await run(observer,'08_cleanup.sql');
        const remaining=await inventory(observer);report.cleanup={result:remaining.length?'FAIL':'PASS',remaining};
      }catch(e){report.cleanup={result:'FAIL',error:safeError(e),remaining:null};
        try{await boundedQuery(observer,'rollback',undefined,3000);report.cleanup.remaining=await inventory(observer);}catch{report.cleanup.remaining='UNVERIFIED; use created_fixture_manifest, do not declare clean';}}
    }else{
      report.cleanup={result:baselinePassed?'NO_COMMITTED_FIXTURES':'NOT_NEEDED_NO_WRITES',remaining:[]};
      if(baselinePassed && observer){try{report.cleanup.remaining=await inventory(observer);if(report.cleanup.remaining.length)report.cleanup.result='FAIL';}catch{report.cleanup={result:'UNVERIFIED',remaining:null};}}
    }
    await Promise.all(clients.map(close));
    clearTimeout(blockTimer);process.removeListener('SIGINT',abort);process.removeListener('SIGTERM',abort);
    emit({stage:'cleanup',...report.cleanup});
  }
}
async function main() {
  const report={project:PROJECT,head:HEAD,environment:'Supabase DEV — execution only if target/TLS checks pass',started_at:new Date().toISOString(),tests:[],races:[],
    prior_installation:'user-reported Success. No rows returned; not rerun',prior_checks:'user-reported Success. No rows returned; not rerun',
    ui_server_gateway:'LOCAL/SIMULATED tests only; not certified by SQL',vercel_deployments:'PENDING supported metadata access'};
  let credential;let stage='package_validation';
  const emit=e=>console.log(JSON.stringify(e));
  const reportPath=join(DIRECTORY,'dev-execution-report.json');
  try{
    const diagnosticMode=process.argv.length===3&&process.argv[2]==='--diagnose-schema';
    if(process.argv.length!==2&&!diagnosticMode)throw failure('no_credential_or_options_allowed_in_process_arguments');
    const sql=await loadSql();
    // Exclusive local attempt marker: prevents accidental automatic re-execution of this block.
    const claim=await open(join(DIRECTORY,'dev-attempt.claim'),'wx',0o600);
    await claim.writeFile(JSON.stringify({head:HEAD,project:PROJECT,started_at:report.started_at}));await claim.close();
    stage='official_root_reuse';const officialRoot=await loadReceivedOfficialRoot();
    report.trust_anchor={source:OFFICIAL_CA_SETTINGS,provenance:'reused official dashboard file; fingerprint matches previous user selection; not obtained from peer',...officialRoot.metadata};
    emit({stage:'official_root_loaded',...report.trust_anchor});
    stage='secure_capture';credential=await captureCredential();
    if(credential.host!==VERIFIED_HOST || credential.mode!=='session_pooler')throw failure('previously_verified_server_required');
    const config=clientConfig(credential,officialRoot);report.target={host:credential.host,port:5432,mode:credential.mode,project_route_verified:true,tls:'explicit official CA; rejectUnauthorized=true; default hostname verification'};
    const {default:pg}=await import(pathToFileURL(PG_MODULE));
    stage='database_connection';
    const openClient=async()=>{
      const c=new pg.Client(config);c.on('error',()=>{});
      let peer=[];
      c.connection.on('sslconnect',()=>{
        const stream=c.connection.stream;
        // Capture public metadata before Node's normal verifier may close a rejected handshake.
        stream.prependOnceListener('secure',()=>{peer=peerCertificateMetadata(stream);});
        stream.on('error',()=>{if(!peer.length)peer=peerCertificateMetadata(stream);});
      });
      try{
        assertEffectiveTls(c,config);
        report.effective_tls={explicit_ca:true,rejectUnauthorized:true,hostname_validation:'Node default',servername:config.host,connectionString_forwarded:false};
        await c.connect();
        const stream=c.connection?.stream;
        if(!stream?.encrypted||stream.authorized!==true)throw failure('tls_peer_not_verified');
        const r=await boundedQuery(c,"select current_user as db_role,current_database() as db,pg_backend_pid() as pid,current_setting('server_version_num') as server_version_num",undefined,5000);
        if(r.rows[0]?.db_role!=='postgres'||r.rows[0]?.db!=='postgres')throw failure('database_context_mismatch');
        const connectionEvidence={stage:'database_session_verified',tls_authorized:true,hostname_verified:true,authenticated:true,backend_pid:r.rows[0].pid,
          peer_certificates:peer.length?peer:peerCertificateMetadata(stream)};
        (report.connections??=[]).push(connectionEvidence);emit(connectionEvidence);
        c.certPid=r.rows[0].pid;report.server_version_num=r.rows[0].server_version_num;return c;
      }catch(e){
        report.connection_failure={...safeError(e),peer_certificates:peer.length?peer:peerCertificateMetadata(c.connection?.stream)};
        if(!report.connection_failure.peer_certificates.length)report.connection_failure.peer_metadata='unavailable from this failed handshake; no insecure retry';
        emit({stage:'database_connection_failed',...report.connection_failure});
        await close(c);throw e;
      }
    };
    if(diagnosticMode){
      stage='schema_diagnostic';const c=await openClient();let diag;
      try{diag=await diagnoseSchema(c,report,emit);}finally{await close(c);}
      if(diag.checks.some(x=>x.result==='FAIL'&&x.condition==='single installed function body identical to certified migration'))throw failure('installed_migration_function_differs_stop');
      if(await waitForDiagnosticDecision()!=='CONTINUE_AFTER_PACKAGE_FIX')throw failure('stopped_after_read_only_schema_diagnostic');
      // Reload only locally corrected package/hashes; credential remains solely in this bounded process memory.
      const revised=await import(import.meta.url+'?certified_package_revision='+Date.now());
      if(revised.PROJECT!==PROJECT||revised.HEAD!==HEAD)throw failure('package_scope_changed');
      await revised.executeBlock({openClient,sql:await revised.loadSql(),report,emit});
    }else await executeBlock({openClient,sql,report,emit});
  }catch(e){report.database_tests='NOT_EXECUTED';report.blocker={stage,...safeError(e)};report.cleanup={result:'NOT_NEEDED_NO_WRITES',remaining:[]};emit(report.blocker);}
  finally{
    if(credential)credential.password='';
    report.finished_at=new Date().toISOString();
    report.result=report.database_tests==='PASS'&&report.cleanup?.result==='PASS'?'DATABASE_CERTIFICATION_PASS':'NO_GO_PENDING_OR_FAILED';
    await writeFile(reportPath,JSON.stringify(report,null,2)+'\n',{mode:0o600});
    emit({result:report.result,report:reportPath});
  }
}
if(!new URL(import.meta.url).search&&process.argv[1]&&fileURLToPath(import.meta.url)===process.argv[1]) main().catch(()=>{console.log('{"result":"FAIL_CLOSED","code":"launcher_internal_error"}');process.exitCode=1;});
