-- PR #133 HEAD e0cdda009dc1d9fbb92ccd67b1977bc18ab7d8bf
-- SOLO inmoadmin-dev / hjfwjnejbcpmknvfpdcq. Verificar proyecto en UI antes de ejecutar.
-- Prueba sintetica, NO migracion. No ejecutar en Produccion.
begin;
set local statement_timeout='40s';
set local lock_timeout='5s';
set local idle_in_transaction_session_timeout='45s';
create temporary table pr133_results(check_name text primary key, result text not null) on commit drop;
create or replace function pg_temp.pr133_id(n integer) returns uuid language sql immutable as $$
 select ('133c2026-0918-4000-8000-'||lpad(n::text,12,'0'))::uuid $$;
create or replace function pg_temp.pr133_phone(n integer) returns text language sql immutable as $$
 select '52000013'||lpad(n::text,4,'0') $$;
create or replace function pg_temp.pr133_contact(n integer) returns text language sql immutable as $$
 select 'pr133-dev-synthetic-20260920-'||n::text $$;
create or replace function pg_temp.pr133_assert(v boolean,label text) returns void language plpgsql as $$
begin
 if v is distinct from true then raise exception 'PR133 ASSERT FAILED: %',label; end if;
 insert into pg_temp.pr133_results values(label,'PASS');
end $$;
grant select,insert on pr133_results to anon,authenticated,service_role;
-- Actores Auth exclusivamente sinteticos en 01/02; sin login, roles nuevos ni permisos del negocio.
create or replace function pg_temp.pr133_unit(n integer, phone_n integer default null, condo_n integer default 20, active_value boolean default true)
returns void language plpgsql as $$
begin
 insert into public.unidades_condominio(id,condominio_id,numero,activo,propietario_telefono,propietario_nombre)
 values(pg_temp.pr133_id(n),pg_temp.pr133_id(condo_n),'PR133-'||n,active_value,pg_temp.pr133_phone(coalesce(phone_n,n)),'PR133 SYNTHETIC ONLY');
end $$;
create or replace function pg_temp.pr133_call(n integer, action_name text, candidate uuid default null,
 phone_n integer default null, actor_n integer default 1, contact_n integer default null,
 attach_identity boolean default false, observed_at timestamptz default clock_timestamp())
returns jsonb language sql as $$
 select public.review_condominium_owner_identity(action_name,pg_temp.pr133_id(n),
 pg_temp.pr133_contact(coalesce(contact_n,n)),pg_temp.pr133_id(actor_n),
 encode(extensions.digest(pg_temp.pr133_phone(coalesce(phone_n,n)),'sha256'),'hex'),
 observed_at,candidate,null,attach_identity) $$;

-- Precondiciones: fallo = detener, NO adaptar el esquema ni aplicar otras migraciones.
do $$
declare r record; bad text;
begin
 if current_user<>'postgres' then raise exception 'PR133 requires DEV SQL Editor postgres role'; end if;
 if to_regprocedure('public.review_condominium_owner_identity(text,uuid,text,uuid,text,timestamp with time zone,uuid,text,boolean)') is null then
  raise exception 'PR133 installed reviewer missing'; end if;
 if not exists(select 1 from pg_constraint where conrelid='public.profiles'::regclass and contype='f'
   and conname='profiles_id_fkey' and confrelid='auth.users'::regclass and convalidated
   and conkey=array[(select attnum from pg_attribute where attrelid='public.profiles'::regclass and attname='id')]
   and confkey=array[(select attnum from pg_attribute where attrelid='auth.users'::regclass and attname='id')]) then
  raise exception 'PR133 schema dependency: expected profiles_id_fkey to auth.users.id required'; end if;
 for r in select * from (values
  ('public.profiles',array['id','email','full_name','role_id','role','active','participa_kpis']::text[]),
  ('public.condominios',array['id','nombre','activo']::text[]),
  ('public.unidades_condominio',array['id','condominio_id','numero','activo','propietario_telefono','propietario_nombre']::text[]),
  ('auth.users',array['id','aud','role','email','encrypted_password','raw_app_meta_data','raw_user_meta_data','created_at','updated_at','banned_until','is_sso_user','is_anonymous']::text[])
 ) t(tbl,supplied) loop
  select string_agg(attname,',') into bad from pg_attribute a
   where a.attrelid=r.tbl::regclass and attnum>0 and not attisdropped
     and attnotnull and not atthasdef and attidentity='' and attgenerated=''
     and not attname=any(r.supplied);
  if bad is not null then raise exception 'PR133 schema dependency: %.% required',r.tbl,bad; end if;
 end loop;
 -- Pin the four reviewed triggers, including body, relation, event and enabled mode.
 if exists(select 1 from pg_trigger t join pg_proc p on p.oid=t.tgfoid where not t.tgisinternal and t.tgenabled<>'D'
   and t.tgrelid in ('auth.users'::regclass,'public.profiles'::regclass,'public.condominios'::regclass,'public.unidades_condominio'::regclass,
    'public.client_identities'::regclass,'public.client_identity_roles'::regclass,'public.client_source_links'::regclass,
    'public.client_reconciliation_candidates'::regclass,'public.client_reconciliation_candidate_sources'::regclass,
    'public.client_identity_audit'::regclass,'public.respond_identity_links'::regclass,'public.respond_identity_audit'::regclass)
   and not exists(select 1 from (values
    ('auth.users','on_auth_user_created','public.handle_new_user()',5,'25fe16f206acafd66f67b0967a19d706'),
    ('public.unidades_condominio','condominium_owner_identity_version','public.version_condominium_owner_identity()',19,'221b2328c392a5be762e3944b6e07828'),
    ('public.client_source_links','condominium_identity_source_guard','public.check_condominium_identity_source()',23,'6bd79a33aff7c8ab1dab288dcd38226a'),
    ('public.client_reconciliation_candidate_sources','condominium_candidate_source_guard','public.check_condominium_identity_source()',23,'6bd79a33aff7c8ab1dab288dcd38226a')
   ) expected(tbl,trg,fn,events,body_hash) where t.tgrelid=expected.tbl::regclass and t.tgname=expected.trg
     and t.tgfoid=expected.fn::regprocedure and t.tgtype=expected.events and t.tgenabled='O' and md5(p.prosrc)=expected.body_hash)) then
  raise exception 'PR133 unexpected active trigger: review metadata before inserting fixtures'; end if;
 if not exists(select 1 from pg_trigger where tgrelid='auth.users'::regclass and tgname='on_auth_user_created' and tgenabled='O') then
  raise exception 'PR133 schema dependency: reviewed Auth profile trigger required'; end if;
 if not exists(select 1 from public.roles where id='admin') or not exists(select 1 from public.roles where id='asesor') then
  raise exception 'PR133 schema dependency: existing admin/asesor roles required'; end if;
 -- Cleanup must be able to inspect dependencies without bypassing protections or cascading.
 for r in select distinct conrelid::regclass child_table from pg_constraint where contype='f'
  and confrelid in('auth.users'::regclass,'public.profiles'::regclass,'public.condominios'::regclass,
   'public.unidades_condominio'::regclass,'public.client_identities'::regclass,
   'public.client_reconciliation_candidates'::regclass,'public.respond_identity_links'::regclass) loop
  if not has_table_privilege(current_user,r.child_table,'SELECT') then
   raise exception 'PR133 cleanup SELECT permission missing: %',r.child_table using errcode='42501'; end if;
 end loop;
 -- Colisiones: no reutilizar ningun registro previo, aun si parece de una prueba.
 if exists(select 1 from auth.users where id::text like '133c2026-0918-4000-8000-%' or email like 'pr133.%@example.invalid')
 or exists(select 1 from public.profiles where id::text like '133c2026-0918-4000-8000-%' or email like 'pr133.%@example.invalid')
 or exists(select 1 from public.condominios where id::text like '133c2026-0918-4000-8000-%')
 or exists(select 1 from public.unidades_condominio where id::text like '133c2026-0918-4000-8000-%'
   or public.condominium_identity_phone_digest(propietario_telefono) in
      (select encode(extensions.digest(pg_temp.pr133_phone(n),'sha256'),'hex') from generate_series(0,999) n))
 or exists(select 1 from public.client_identities where id::text like '133c2026-0918-4000-8000-%'
   or phone_digest in (select encode(extensions.digest(pg_temp.pr133_phone(n),'sha256'),'hex') from generate_series(0,999) n))
 or exists(select 1 from public.respond_identity_links where respond_contact_id like 'pr133-dev-synthetic-20260920-%')
 or exists(select 1 from public.client_reconciliation_candidates where respond_contact_id like 'pr133-dev-synthetic-20260920-%') then
  raise exception 'PR133 fixture collision: do not overwrite or retry setup'; end if;
end $$;
-- Three inert Auth parents; no password, session, invitation, email/SMS or Auth API.
-- The reviewed AFTER INSERT trigger creates the profiles as staff/asesor.
insert into auth.users(id,aud,role,email,encrypted_password,raw_app_meta_data,raw_user_meta_data,
 created_at,updated_at,banned_until,is_sso_user,is_anonymous)
select pg_temp.pr133_id(n),'authenticated','authenticated',email,null,
 '{"fixture_package":"pr133-dev-20260920"}'::jsonb,'{}'::jsonb,now(),now(),'infinity'::timestamptz,false,false
from (values(1,'pr133.admin@example.invalid'),(2,'pr133.nonadmin@example.invalid'),(3,'pr133.inactive@example.invalid')) a(n,email);
select pg_temp.pr133_assert((select count(*)=3 from public.profiles where id in
 (pg_temp.pr133_id(1),pg_temp.pr133_id(2),pg_temp.pr133_id(3)) and role_id='asesor' and role='staff'),'Auth trigger created exactly three synthetic profiles');
update public.profiles p set full_name='PR133 SYNTHETIC ONLY',role_id=a.role_id,role=a.role,
 active=a.active,participa_kpis=false
from (values(1,'admin','admin',true),(2,'asesor','staff',true),(3,'admin','admin',false)) a(n,role_id,role,active)
where p.id=pg_temp.pr133_id(a.n);
select pg_temp.pr133_assert((select count(*)=3 from auth.users where id in
 (pg_temp.pr133_id(1),pg_temp.pr133_id(2),pg_temp.pr133_id(3))
 and encrypted_password is null and last_sign_in_at is null and invited_at is null
 and email_confirmed_at is null and phone_confirmed_at is null and confirmation_sent_at is null
 and recovery_sent_at is null and phone_change_sent_at is null and banned_until='infinity'::timestamptz),
 'synthetic Auth actors have no credentials or communications');
insert into public.condominios(id,nombre,activo) values
 (pg_temp.pr133_id(20),'PR133 SYNTHETIC CONDOMINIUM 20',true),(pg_temp.pr133_id(21),'PR133 SYNTHETIC CONDOMINIUM 21',false);

-- Todo este archivo termina en ROLLBACK. Ni la auditoria sintetica se conserva.
select pg_temp.pr133_unit(n) from generate_series(101,104) n;
select pg_temp.pr133_unit(105,105); select pg_temp.pr133_unit(106,105);
select pg_temp.pr133_unit(107,107,20,false); select pg_temp.pr133_unit(108,108,21,true);
select pg_temp.pr133_unit(109); select pg_temp.pr133_unit(110);
create temporary table pr133_legacy on commit drop as
 select oid,md5(pg_get_functiondef(oid)) fingerprint from pg_proc where pronamespace='public'::regnamespace
 and proname in ('confirm_exact_phone_respond_identity_link','confirm_exact_phone_respond_identity_link_core');
-- Pruebas de privilegios reales. Solo grants sobre la tabla TEMP de resultados.
set local role anon;
do $$ begin
 begin
  perform public.review_condominium_owner_identity('prepare','133c2026-0918-4000-8000-000000000101','pr133-dev-synthetic-20260920-101','133c2026-0918-4000-8000-000000000001',null,null,null,null,false);
  raise exception 'PR133 unexpected anon access';
 exception when insufficient_privilege then perform pg_temp.pr133_assert(true,'anon RPC denied'); end;
end $$;
reset role;
set local role authenticated;
do $$ begin
 begin
  perform public.review_condominium_owner_identity('prepare','133c2026-0918-4000-8000-000000000101','pr133-dev-synthetic-20260920-101','133c2026-0918-4000-8000-000000000001',null,null,null,null,false);
  raise exception 'PR133 unexpected authenticated access';
 exception when insufficient_privilege then perform pg_temp.pr133_assert(true,'authenticated RPC denied'); end;
end $$;
reset role;
set local role service_role;
do $$
declare n integer; r jsonb; cid uuid; iid uuid; extra uuid; err text; audit_count integer;
begin
 for n in select unnest(array[2,3,999]) loop
  begin
   perform pg_temp.pr133_call(101,'prepare',null,null,n);
   raise exception 'PR133 unexpected unauthorized actor success';
  exception when raise_exception then
   get stacked diagnostics err=message_text;
   if err<>'actor_not_authorized' then raise; end if;
   perform pg_temp.pr133_assert(true,'actor denied '||n); end;
 end loop;
 r:=pg_temp.pr133_call(101,'prepare',null,null,1,null,false,clock_timestamp()-interval '61 seconds');
 perform pg_temp.pr133_assert(r->>'reason'='fresh_respond_evidence_required','stale evidence rejected');
 r:=pg_temp.pr133_call(104,'prepare',null,999);
 perform pg_temp.pr133_assert(r->>'reason'='source_phone_mismatch','unmatched fourth fixture rejected');
 r:=pg_temp.pr133_call(105,'prepare');
 perform pg_temp.pr133_assert(r->>'reason'='shared_phone_requires_structured_identity','shared phone not identity');
 r:=pg_temp.pr133_call(107,'prepare');
 perform pg_temp.pr133_assert(r->>'reason'='inactive_unit_or_condominium','inactive unit rejected');
 r:=pg_temp.pr133_call(108,'prepare');
 perform pg_temp.pr133_assert(r->>'reason'='inactive_unit_or_condominium','inactive condominium rejected');
 for n in 101..103 loop
  r:=pg_temp.pr133_call(n,'prepare'); cid:=(r->>'candidate_id')::uuid;
  perform pg_temp.pr133_assert(r->>'status'='requires_review','candidate requires human review '||n);
  perform pg_temp.pr133_assert(not exists(select 1 from public.respond_identity_links where respond_contact_id=pg_temp.pr133_contact(n)),
   'candidate creates no Respond link '||n);
  r:=pg_temp.pr133_call(n,'prepare');
  perform pg_temp.pr133_assert(r->>'reason'='already_prepared' and (r->>'candidate_id')::uuid=cid,'prepare idempotent '||n);
  if n=101 then
   begin
    perform public.confirm_client_reconciliation_candidate(cid,pg_temp.pr133_id(1),null);
    raise exception 'PR133 legacy bypass succeeded';
   exception when raise_exception then get stacked diagnostics err=message_text;
    if err<>'condominium_review_required' then raise; end if;
    perform pg_temp.pr133_assert(true,'legacy wrapper blocks condominium'); end;
   begin
    perform public.confirm_rental_client_candidate_v1(cid,pg_temp.pr133_id(1),null);
    raise exception 'PR133 legacy core bypass succeeded';
   exception when insufficient_privilege then perform pg_temp.pr133_assert(true,'legacy core denied'); end;
  end if;
  r:=pg_temp.pr133_call(n,'confirm',cid);
  perform pg_temp.pr133_assert(r->>'status'='confirmed','synthetic admin confirmation '||n);
  select client_identity_id into iid from public.client_reconciliation_candidates where id=cid;
  perform pg_temp.pr133_assert(exists(select 1 from public.client_source_links s
   join public.client_identities i on i.id=s.client_identity_id
   join public.client_identity_roles ir on ir.client_identity_id=i.id
   join public.respond_identity_links l on l.client_identity_id=i.id
   join public.unidades_condominio u on u.id=s.source_id
   where s.source_type='condominium_unit_owner' and s.source_id=pg_temp.pr133_id(n)
    and s.condominium_id=pg_temp.pr133_id(20) and s.source_version=u.identity_owner_version
    and s.link_status='confirmed' and i.status='active' and ir.role_kind='owner' and ir.status='active'
    and l.respond_contact_id=pg_temp.pr133_contact(n) and l.link_status='confirmed'
    and l.link_source='condominium_owner_admin_review'),'durable source identity Respond relation '||n);
  r:=pg_temp.pr133_call(n,'confirm',cid);
  perform pg_temp.pr133_assert(r->>'status'='already_confirmed','confirm idempotent '||n);
  select count(*) into audit_count from public.client_identity_audit where candidate_id=cid and event_type='confirmed';
  perform pg_temp.pr133_assert(audit_count=1,'one confirmation audit '||n);
 end loop;
 -- Actual Respond mismatch after prepare, without changing the stored source.
 r:=pg_temp.pr133_call(109,'prepare'); cid:=(r->>'candidate_id')::uuid;
 r:=pg_temp.pr133_call(109,'confirm',cid,999);
 perform pg_temp.pr133_assert(r->>'reason'='source_phone_mismatch','changed current phone rejected');
 -- The fixed historical operation still rejects an eighth reference before any write.
 begin
  perform public.confirm_exact_phone_respond_identity_link('eighth',pg_temp.pr133_id(900),'synthetic',null,
   clock_timestamp(),'exact_phone_unique_confirmation_v2',null,pg_temp.pr133_id(1));
  raise exception 'PR133 eighth reference unexpectedly accepted';
 exception when raise_exception then get stacked diagnostics err=message_text;
  if err<>'candidate_ref_not_in_certified_cohort' then raise; end if;
  perform pg_temp.pr133_assert(true,'historical seventh cohort unchanged eighth rejected'); end;
end $$;
reset role;
-- Only own fixture sources are updated below.
select pg_temp.pr133_unit(111,101);
set local role service_role;
do $$
declare r jsonb; cid uuid; iid uuid;
begin
 r:=pg_temp.pr133_call(111,'prepare',null,101,1,101);
 perform pg_temp.pr133_assert(r->>'status'='rejected','second unit not inferred by phone');
 r:=pg_temp.pr133_call(111,'prepare',null,101,1,101,true); cid:=(r->>'candidate_id')::uuid;
 perform pg_temp.pr133_assert(r->>'status'='requires_review','additional unit explicit reviewed candidate');
 r:=pg_temp.pr133_call(111,'confirm',cid,101,1,101);
 perform pg_temp.pr133_assert(r->>'status'='confirmed','additional unit explicit confirmation');
 select client_identity_id into iid from public.client_reconciliation_candidates where id=cid;
 perform pg_temp.pr133_assert((select count(*) from public.client_source_links where client_identity_id=iid
  and source_type='condominium_unit_owner' and link_status='confirmed')=2,'one identity two approved units');
 perform pg_temp.pr133_assert((select count(*) from public.client_identities where phone_digest=
  encode(extensions.digest(pg_temp.pr133_phone(101),'sha256'),'hex'))=1,'no duplicate person for two units');
 r:=pg_temp.pr133_call(111,'revoke',cid,101,1,101);
 perform pg_temp.pr133_assert(r->>'status'='revoked','revoke additional unit');
 perform pg_temp.pr133_assert(exists(select 1 from public.respond_identity_links where client_identity_id=iid
  and link_status='confirmed'),'revocation preserves other approved unit');
 r:=pg_temp.pr133_call(111,'revoke',cid,101,1,101);
 perform pg_temp.pr133_assert(r->>'status'='already_revoke','revoke idempotent');
end $$;
reset role;
update public.unidades_condominio set propietario_nombre='PR133 CHANGED SYNTHETIC OWNER' where id=pg_temp.pr133_id(102);
set local role service_role;
do $$
declare r jsonb; cid uuid;
begin
 select id into cid from public.client_reconciliation_candidates where respond_contact_id=pg_temp.pr133_contact(102);
 r:=pg_temp.pr133_call(102,'confirm',cid);
 perform pg_temp.pr133_assert(r->>'reason'='source_relationship_changed','changed owner same phone invalidates relationship');
 select id into cid from public.client_reconciliation_candidates where respond_contact_id=pg_temp.pr133_contact(103);
 r:=pg_temp.pr133_call(103,'revoke',cid);
 perform pg_temp.pr133_assert(r->>'status'='revoked','revoke last unit');
 perform pg_temp.pr133_assert(not exists(select 1 from public.respond_identity_links
  where respond_contact_id=pg_temp.pr133_contact(103) and link_status='confirmed'),'last unit revocation blocks Respond link');
 r:=pg_temp.pr133_call(103,'confirm',cid);
 perform pg_temp.pr133_assert(r->>'reason'='revoked_relationship','revoked relation not silently reconfirmed');
end $$;
reset role;
do $$
begin
 perform pg_temp.pr133_assert(not exists(select 1 from pr133_legacy b
  join pg_proc p on p.oid=b.oid where b.fingerprint<>md5(pg_get_functiondef(p.oid))),'historical wrapper core definitions unmodified');
 perform pg_temp.pr133_assert(not exists(select 1 from public.client_identity_audit a
  where a.actor_profile_id=pg_temp.pr133_id(1) and (a.context_ids::text like '%52000013%'
   or a.context_ids::text like '%SYNTHETIC%' or a.context_ids ? 'phone' or a.context_ids ? 'propietario_telefono')),
  'canonical audit no synthetic raw phone or name');
 perform pg_temp.pr133_assert(not exists(select 1 from public.respond_identity_audit a
  where a.actor_profile_id=pg_temp.pr133_id(1) and (a.context_ids::text like '%52000013%'
   or a.context_ids::text like '%SYNTHETIC%' or a.context_ids ? 'phone')),
  'Respond audit no synthetic raw phone or name');
end $$;
select check_name,result from pr133_results order by check_name;
-- Obligatorio: no sustituir por COMMIT.
rollback;
select 'PR133 behavior completed; all synthetic writes rolled back' as result;
